#Exercício 56 - Cadastro

print('----1ªª PESSOA----')
nome = input('Digite o seu nome completo: ').upper().strip()
idade = int(input('Digite a sua idade: '))
sexo = input('Digite o seu sexo (M / F): ').upper().strip()

nomemaior = nome
mediaidade = idade
idademaior = 0
qtdmulheres = 0

if sexo == "M":
    idademaior = idade
else:
    if idade < 20:
        qtdmulheres += 1

for c in range (2, 4+1 ):
    print('----{}ª PESSOA----'.format(c))
    nome = input('Digite o seu nome completo: ').upper().strip()
    idade = int(input('Digite a sua idade: '))
    mediaidade += idade
    sexo = input('Digite o seu sexo (M / F): ').upper().strip()
    if sexo == "M":
        if idade > idademaior:
            nomemaior = nome
            idademaior = idade
    else:
        if idade < 20:
            qtdmulheres += 1

mediaidade = mediaidade/4

print('A média de idade das pessoas cadastradas é {} anos.'.format(mediaidade))
print('O  homem mais velho é {}, e ele tem {} anos.'.format(nomemaior.upper(), idademaior))
print('Ao todo, são {} mulheres com menos de 20 anos.'.format(qtdmulheres))