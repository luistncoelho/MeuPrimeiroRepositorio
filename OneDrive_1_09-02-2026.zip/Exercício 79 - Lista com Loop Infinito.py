#Exercício 79 - Lista com Loop Infinito

print('Exercício 79 - Lista com Loop Infinito')

lista = []

while True:
    continuar = ' '
    n = int(input('Digite o número: '))
    if n in lista:
        print('Número DUPLICADO. Não será adicionado à lista.')
    else:
        print('Número adicionado com sucesso.')
        lista.append(n)
    while continuar not in 'SN':
        continuar = input('Deseja adicionar um novo número (S/N)? ').upper()
    if continuar == 'N':
        break
lista.sort()
print(f'Esta é a sua lista final, em ordem crescente: {lista}')