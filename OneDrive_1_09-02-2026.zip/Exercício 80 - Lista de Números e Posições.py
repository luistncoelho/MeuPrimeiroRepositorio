#Exercício 80 - Lista de Números e Posições

print('----Exercício 80 - Lista de Números e Posições----')

n = int(input('Digite o primeiro número: '))
lista = [n]
print('Primeiro número adicionado com sucesso. ')

n = int(input('Digite o segundo número: '))
lista.append(n)
lista.sort()
pos = lista.index(n)
if pos == 0:
    print('Número adicionado na posição inicial. ')
else:
    print('N[umero adicionado na posição final. ')

n = int(input('Digite o terceiro número: '))
lista.append(n)
lista.sort()
pos = lista.index(n)
if pos == 0:
    print('Número adicionado na posição inicial. ')
elif pos == len(lista)-1:
    print('Número adicionado na posição final. ')
else:
    print(f'Número adicionado na posição {pos}.')

n = int(input('Digite o quarto número: '))
lista.append(n)
lista.sort()
pos = lista.index(n)
if pos == 0:
    print('Número adicionado na posição inicial. ')
elif pos == len(lista)-1:
    print('Número adicionado na posição final. ')
else:
    print(f'Número adicionado na posição {pos}.')

n = int(input('Digite o quinto número: '))
lista.append(n)
lista.sort()
pos = lista.index(n)
if pos == 0:
    print('Número adicionado na posição inicial. ')
elif pos == len(lista)-1:
    print('Número adicionado na posição final. ')
else:
    print(f'Número adicionado na posição {pos}.')

print('-='*50)
print(f'Os números digitados na lista, em ordem crescente de valores, são: {lista}')


