#Exercício 81 - Lista de Números (Decrescente com o 5)

print('-----Exercício 81 - Lista de Números (Decrescente com o 5)-----')

lista = []
cinco = 0

while True:
    continuar = ' '
    n = int(input('Digite o número desejado: '))
    lista.append(n)
    while continuar not in 'SN':
        continuar = input('Deseja continuar (S/N)? ').upper()
    if continuar == 'N':
        break

lista.sort(reverse=True) #O comando 'REVERSE=TRUE' coloca a lista em ordem descrescente

print(f'A quantidade de valores digitados foi: {len(lista)}')
print(f'A lista de valores, em ordem decrescente é: {lista}')

if 5 in lista:
    print('O valor 5 está na lista.')
else:
    print('O valor 5 não está na lista.')