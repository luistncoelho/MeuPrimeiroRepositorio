#Exercício 71 - Caixa Eletrônico

print('----Caixa Eletrônico----')

valor = 0
resto = 0
nt50 = 0
nt20 = 0
nt10 = 0
nt1 = 0
int50 = 0
int20 = 0
int10 = 0
int1 = 0

while True:
    saque = str(input('Deseja realizar saques [S / N]? ')).strip().upper()[0]
    if saque == 'S' or saque == 'N':
        break
if saque == 'S':
    valor = int(input('Qual valor deseja sacar? R$: '))
    resto = valor
    if valor >= 50:
       nt50 = valor // 50
       int50 = nt50 * 50
       resto = valor - int50
    if resto >= 20:
       nt20 = resto // 20
       int20 = nt20 * 20
       resto -= int20
    if resto >= 10:
       nt10 = resto // 10
       int10 = nt10 * 10
       resto -= int10
    if resto >= 1:
       nt1 = resto // 1
       int1 = nt1 * 1
       resto -= int1

print(f'Cédulas de R$50 = {nt50}')
print(f'Cédulas de R$20 = {nt20}')
print(f'Cédulas de R$10 = {nt10}')
print(f'Cédulas de R$1 = {nt1}')


