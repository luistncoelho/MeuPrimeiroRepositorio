#Exercício 37 - Decimal para Binário / Octal / Hexadecimal

n = int(input('Digite um número inteiro: '))
base = input('Escolha a opção da base de conversão do número entre:\n'
             '1) Binário\n'
             '2) Octal\n'
             '3) Hexadecimal\n'
             'Digite a sua opção: '
             )

if base == '1':
    print(bin(n).replace('0b',''))
    # O comando 'REPLACE' entra para remover o código '0b' retornado pela função BIN (Binário), no resultado
elif base == '2':
    print(oct(n).replace('0o',''))
    # O comando 'REPLACE' entra para remover o código '0o' retornado pela função OCT (Octal), no resultado
elif base == '3':
    print(hex(n).replace('0x',''))
    # O comando 'REPLACE' entra para remover o código '0x' retornado pela função HEX (Hexadecimal), no resultado
else:
    print('Você não digitou uma opção válida.')

print('FIM')

#Função 'bin()' transforma o número em binário
#Função 'oct()' transforma o número em octal
#Função 'hex()' transforma o número em hexadecimal