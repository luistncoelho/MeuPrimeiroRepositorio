#Exercício 82 - Lista Geral - Lista Par - Lista Ímpar

print('----Exercício 82 - Lista Geral - Lista Par - Lista Ímpar----')

lista = []
listapar = []
listaimpar = []

while True:
    continuar = ' '
    n = int(input('Digite o número desejado: '))
    lista.append(n)
    if n % 2 == 0:
        listapar.append(n)
    else:
        listaimpar.append(n)
    while continuar not in 'SN':
        continuar = input('Deseja inserir outro número (S/N)? ').upper()
    if continuar == 'N':
        break
lista.sort()
listapar.sort()
listaimpar.sort()

print(f'A lista geral é: {lista}')
print(f'A lista com os números pares é: {listapar}')
print(f'A lista com os números ímpares é: {listaimpar}')

