#Exercício 83 - Parênteses

print('----Exercício 83 - Parênteses----')

listaaberto = []
listafechado = []

formula = input('Digite a sua fórmula: ')
for c in range(0, len(formula)):
    if formula[c] == '(':
        listaaberto.append(formula[c])
    elif formula[c] == ')':
        listafechado.append(formula[c])

if len(listaaberto) == len(listafechado):
    print('Sua fórmula está perfeita!')
else:
    print('Você esqueceu de abrir/fechar algum parênteses.')

print(listaaberto)
print(listafechado)