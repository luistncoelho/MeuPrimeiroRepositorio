#Exercício 23 - "Separando" um número

numero = input('Digite um número entre 0 e 9999: ')

numero = numero.strip()
unidade = numero[3]
dezena = numero[2]
centena = numero[1]
milhar = numero[0]

print('unidade = {}'.format(unidade))
print('dezena = {}'.format(dezena))
print('centena = {}'.format(centena))
print('milhar = {}'.format(milhar))