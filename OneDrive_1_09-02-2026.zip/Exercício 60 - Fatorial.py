#Exercício 60 - Fatorial

print('----FATORIAL----')

n = int(input('Digite um número inteiro: '))
c = 1 #Começamos com 1 para que a multiplicação saia do ZERO
fatorial = 1 #Começamos com 1 para que a multiplicação saia do ZERO

while c < n+1: #n+1 para que a multiplicação do C chegue ao N requerido (último multiplicador FATORIAL)
    print('{}'.format(c), end=' ') #Aqui, o contador C será mostrado até o N requerido (tirado do Curso em Vídeo)
    print(' x ' if c < n else ' = ', end=' ') #Condição IF/ELSE dentro do PRINT para colocar os 'X' e '=' dentro da resposta (tirado do Curso em Vídeo)
    fatorial *= c #Comando ' *= ' multiplica a própria variável pelo valor seguinte. Similar ao ' += ', ou '-= '.
    c += 1 #Aqui vai limitar o WHILE (quando chegar no C = N, o laço acaba)

print('{}'. format(fatorial))
print('\nO Fatorial de {} é igual à {}.'.format(n, fatorial))