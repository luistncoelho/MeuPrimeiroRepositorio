# Curso em Vídeo - Exercícios de Operadores Aritméticos - Ex.5 à Ex.13

print('#Exercício 5 - Antecessor e Sucessor')
n = int(input('Digite um número: '))
print('O número é {} \nseu antecessor é {} \ne o seu sucessor é {}'.format(n, n-1, n + 1))
print()


print('#Exercício 6 - Dobro - Triplo - Raiz Quadrada')
n = int(input('Digite um número: '))
print('O número é {} \nseu dobro é {} \nseu triplo é {} \nsua raiz quadrada é {:.3f}'.format(n, n*2, n*3, n**(1/2)))
print()


print('#Exercício 7 - Média do Aluno (2 Notas)')
n1 = int(input('Digite a Nota 1: '))
n2 = int(input('Digite a Nota 2: '))
media = float((n1+n2)/2)
print('A média é {:.1f}'.format(media))
print()


print('#Exercício 8 - Metros, Centrímetros e Milímetros')
n = float(input('Digite um número: '))
print('O número em centímetros é {:.0f} \nO número em milímetros é {:.0f}'.format(n*100, n*1000))
print()


print('#Exercício 9 - Tabuada')
n = float(input('Digite um número: '))
print('-'*20)
print('A tabuada do número digitado é: \n{:.0f}x1 = {} \n{:.0f}x2 = {} \n{:.0f}x3 = {} \n{:.0f}x4 = {} \n{:.0f}x5 = {} '
      '\n{:.0f}x6 = {} \n{:.0f}x7 = {} \n{:.0f}x8 = {} \n{:.0f}x9 = {} \n{:.0f}x10 = {}'.format(n, n*1, n, n*2, n, n*3,
      n, n*4, n, n*5, n, n*6, n, n*7, n, n*8, n, n*9, n, n*10))
print('-'*20)
print()


print('#Exercício 10 - Conversor de Moedas')
n = float(input('Digite o valor em reais: '))
cotação = float(input('Digite o valor da cotação do dólar: '))
print('Com este valor em reais, sendo que U$1.00 está R${:.2f}, você pode comprar: U${:.2f}'.format(cotação, n/cotação))
print()


print('#Exercício 11 - Quantidade de tinta em uma Parede')
largura = float(input('Digite o valor da largura da parede: '))
altura = float(input('Digite o valor da altura da parede: '))
rendimento = float(input('Digite quantos m² a lata de tinta rende: '))
print('A quantidade de tinta necessária para pintar esta parede é de {} latas com rendimento de {}m²'
      .format((largura*altura)/rendimento, rendimento))
print()


print('#Exercício 12 - Preço com 5% de Desconto')
n = float(input('Digite o preço do produto: '))
desconto = float(input('Digite o valor do desconto, sem o símbolo da porcentagem: '))
print('O valor do produto com {}% de desconto é de R${}'.format(desconto, (n-(n*(desconto/100)))))
print()


print('#Exercício 13 - Aumento de Salário')
n = float(input('Digite o seu salário: '))
aumento = float(input('Digite qual a porcentagem do aumento: '))
print('O valor do seu salário, após receber o aumento de {}%, será R${} '.format(aumento, (n+(n*aumento/100))))
print()

print('#Exercício 14 - Conversor de Temperatura de ºC para ºF')
t = float(input('Digite a temperatura em ºC: '))
f = (t*1.8)+32
print('A temperatura atual é de {:.1f}ºF'.format(f))
print()

print('#Exercício 15 - Aluguel de Carros')
print('Olá, seja bem vindo à LT Aluguel de Veículos. Vamos calcular o valor da sua locação.\nLembre-se que o valor da '
      'diária é de R$60,00 e o valor por Km rodado é de R$0,15.')
km = float(input('Quantos Km foram percorridos? '))
d = int(input('Quantos dias você ficou com o carro? '))
p = (km*0.15)+(d*60)
print('O preço final da locação é de R${:.2f}'.format(p))