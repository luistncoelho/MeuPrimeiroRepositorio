#Exercício 75 - Tupla com Valores do Teclado

print('----Tupla com Valores do Teclado----')

prinumero = int(input('Digite o primeiro número: '))
segnumero = int(input('Digite o segundo número: '))
ternumero = int(input('Digite o terceiro número: '))
quanumero = int(input('Digite o quarto e último número: '))

tupla = (prinumero, segnumero, ternumero, quanumero)
valornove = tupla.count(9)
qtdpar = 0

print('-'*100)
print(f'Você digitou os números: {tupla}')

print('-'*100)
print(f'O número 9 apareceu {valornove} vezes.')

print('-'*100)
if 3 in tupla:
    valortres = tupla.index(3)+1
    print(f'O número 3 apareceu na {valortres}ª posição')
else:
    print('O número 3 não foi digitado.')

print('-'*100)

print('Os números pares digitados foram:', end=' ')
for c in tupla:
    if c % 2 == 0:
        qtdpar += 1
        print(c, end=' ')

print(f'. Totalizando {qtdpar} números pares.')