#Teste Tabelas - DataFrame (Pandas)

print('Teste Tabelas - DataFrame (Pandas)')
import pandas as pd

dados = {
        'Nome': ['Joao', 'Maria', 'Pedro'],
        'Idade': [20, 18, 22],
        'Nota': [8.5, 9.2, 7.8]
        } #Esse comando entre chaves {} cria um "Dicionário" no Python

df = pd.DataFrame(dados) # DataFrame é o comando do PANDAS que organiza uma tabela. Aqui, utilizamos um dicionário para organizar as listas e dar nomes às Colunas (comando acima).
print(df)