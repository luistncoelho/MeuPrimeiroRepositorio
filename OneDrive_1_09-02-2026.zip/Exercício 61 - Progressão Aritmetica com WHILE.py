#Exercício 61 - Progressão Aritimética com WHILE

print('----Progressão Aritmética (10 Termos)----')

primeirotermo = int(input('Digite o primeiro termo da sua progressão: '))
razao = int(input('Digite a Razão da sua progressão: '))
c = 1

print(primeirotermo, end=' ')

while c <= 9: #São 10 termos. Porém aqui colocamos 9 porque o 1º já foi impresso em cima.
    primeirotermo += razao
    c += 1
    print(primeirotermo, end= ' ')