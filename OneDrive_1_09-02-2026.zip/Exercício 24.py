#Exercício 24 - Contém nome (no primeiro)

nomedacidade = input('Digite o nome da sua cidade: ').strip()

nomeemmodulos = (nomedacidade.split()) #divide o nome da cidade em módulos

print('Santo'in nomeemmodulos[0])


#Exercício 25 - Contém nome

nomedapessoa = input('Digite o seu nome: ').strip()

print('Silva'in nomedapessoa)