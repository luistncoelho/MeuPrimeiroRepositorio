#Exercício 98 - Contador (com Função)
import math

print('----Exercício 98 - Contador (com Função)----')

def contador():
    print('----Contador de 1 a 10 com Passo de 1----')
    p = 1
    for c in range(1, 11):
        print(f'{p}', end=' ')
        p += 1
    print(' ')
    print('-'*100)

contador()

def contador2():
    print('----Contador de 1 a 10 com Passo de 2----')
    p = 10
    for c in range(6, 0, -1):
        print(f'{p}', end=' ')
        p -= 2
    print(' ')
    print('-'*100)

contador2()

def contadordinamico(i, f, p): #i = início, f = fim; p = passo
    c = i
    p = int(math.sqrt((pow(passo, 2))))
    if i < f:
        while c <= f:
            print(f'{c}', end=' ')
            c += p
    else:
        while c >= f:
            print(f'{c}', end=' ')
            c -= p

inicio = int(input(f'{"Início:":<8}'))
fim = int(input(f'{"Fim:":<8}'))
passo = int(input(f'{"Passo:":<8}'))
if passo == 0:
    passo = 1

contadordinamico(inicio, fim, passo)