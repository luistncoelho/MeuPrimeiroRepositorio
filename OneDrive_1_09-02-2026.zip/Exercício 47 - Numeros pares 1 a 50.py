#Exercício 47 - Números pares entre 1 e 50

for c in range (0, 51, 2):
    print(c, end=' ')
    #Incremento de 2 em 2. Começa do ZERO para que o próximo seja exatamente 2. Termina em 51 pois o Python
    #remove o último (51), portanto considerará o anterior (50).
    #o "END=' '" coloca os resultados lado à lado.

