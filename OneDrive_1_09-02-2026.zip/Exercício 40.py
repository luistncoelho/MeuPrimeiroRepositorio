#Exercício 40 - Média de NOTAS

print('#Exercício 40 - Média de NOTAS')

n1 = float(input('Digite a nota 1: '))
n2 = float(input('Digite a nota 2: '))
media = (n1+n2)/2

if media < 5:
    print('A média das suas notas é {}. Você está REPROVADO.'.format(media))
elif media >= 5 and media < 7:
    print('A média das suas notas é {}. Você está de RECUPERAÇÃO.'.format(media))
else:
    print('A média das suas notas é {}. Você está APROVADO. Parabéns!!!'.format(media))

print('FIM')