#Exercício 71 - Caixa Eletrônico - Resolução Curso em Vídeo

saque = ' '

while saque not in 'SN':
    saque = str(input('Deseja realizar saques [S / N]? ')).strip().upper()[0]
if saque == 'S':
    valor = int(input('Qual valor deseja sacar? R$: '))
    total = valor
    ced = 50
    totced = 0
    while True:
        if total >= ced:
            total -= ced
            totced += 1
        else:
            if totced > 0:
                print(f'Total de {totced} cédulas de {ced}')
            if ced == 50:
                ced = 20
            elif ced == 20:
                ced = 10
            elif ced == 10:
                ced = 1
            totced = 0
            if total == 0:
                break