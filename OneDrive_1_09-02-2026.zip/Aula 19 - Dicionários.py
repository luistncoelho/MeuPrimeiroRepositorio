#Aula 19 - Dicionários

pessoas = {} #Dicionários são declarados com CHAVES ({}), ou com 'dict()'

pessoas = {'Nome': 'Gustavo', 'Sexo': 'Masculino', 'Idade': 22}
#Os dicionários funcionam com 'chaves' que são nomeadas durante a sua criação.
#Aqui, as chaves são: 'Nome', 'Sexo', 'Idade'.

print(pessoas) #Mostra o dicionário

print(pessoas['Nome']) #Mostra somente a chave 'Nome'.

print('-'*50)
print('---Print Formatado---')

print(f'O {pessoas["Nome"]} tem {pessoas["Idade"]} anos e é do sexo {pessoas["Sexo"]}')

print('-'*50)
print('---Print das Chaves / Valores / Itens ---')

print(pessoas.keys()) #Mostra todas as chaves do dicionário
print(pessoas.values()) #Mostra somente os valores das chaves
print(pessoas.items()) #Mostra tanto as chaves, quanto os valores dentro delas

print('-'*50)
print('---Print das Chaves / Valores / Itens com o FOR---')

for k in pessoas.keys(): #Aqui, o K percorre todas as chaves do dicionário
    print(k)
print('-'*50)

for k in pessoas.values(): #Aqui, o K percorre todos valores das chaves do dicionário
    print(k)
print('-'*50)

for k in pessoas.items(): #Aqui, o K percorre todas as chaves e seus respectivos valores do dicionário
    print(k)
print('-' * 50)

print('---Print dos Valores Formatados, com FOR---')

for k, v in pessoas.items(): #Aqui, o K percorre as chaves e o V extrai os valores de cada uma. Como o ENUMERATE, porém com CHAVES, e não posições.
    print(f'{k} = {v}')
print('-' * 50)

print('---IMPRIMINDO AS CHAVES EM FORMATO DE COLUNAS---')
for k in pessoas.keys():
    print(f'{k:^10}',end='') #O '^' centraliza e o '10' é a quantidade de caracteres. ATENÇÃO na formatação dentro das chaves {}!!!
print() #PULA uma linha para ENCERRAR o END
print('-' * 50)

print('---DELETANDO E ADICIONANDO CHAVES---')

del pessoas['Sexo'] #O DEL deleta a chave indicada (aqui, "sexo")
print(pessoas)
print('-' * 50)

pessoas['Sexo'] = 'Masculino' #Isso adiciona a chave 'SEXO' ao dicionário. Não existe APPEND nos dicionários
print(pessoas)
print('-' * 50)

pessoas['Peso'] = 65 #Adiciona a chave 'PESO' ao dicionário. Não existe APPEND nos dicionários.
print(pessoas)
print('-' * 50)

print('---CRIANDO UM DICIONÁRIO DENTRO DE UMA LISTA---')

brasil = [] #Cria a lista
estado1 = {'UF': 'Rio de Janeiro', 'SIGLA': 'RJ'} #Cria o dicionário
estado2 = {'UF': 'São Paulo', 'SIGLA': 'SP'} #Cria o dicionário
brasil.append(estado1) #Adiciona o primeiro dicionário à lista
brasil.append(estado2) #Adiciona o segundo dicionário à lista

print(estado1) #Mostra o dicionário 1
print(estado2) #Mostra o dicionário 2
print(brasil) #Mostra a lista com os 2 dicionários
print(brasil[0]) #Mostrará a lista, porém somente com o dicionário 1 (que está na posição 0)
print(brasil[1]) #Mostrará a lista, porém somente com o dicionário 2 (que está na posição 1)
print(brasil[0]['UF']) #Mostrará somente a chave 'UF' do dicionário 1 (que está na posição 0)
print(brasil[0]['SIGLA']) #Mostrará somente a chave 'SIGLA' do dicionário 1 (que está na posição 0)
print(brasil[1]['UF']) #Mostrará somente a chave 'UF' do dicionário 2 (que está na posição 1)
print(brasil[1]['SIGLA']) #Mostrará somente a chave 'SIGLA' do dicionário 2 (que está na posição 1)
print('-' * 50)

print('---CRIANDO UM DICIONÁRIO DENTRO DE UMA LISTA COM O FOR---')

estado = dict() #Cria o dicionário
pais = list() #Cria a lista

for c in range(0,3): #Vai automatizar a inserção dos dados no DICIONÁRIO e copiá-lo para uma lista
    estado['UF'] = str(input('Digite o nome do estado: '))
    estado['SIGLA'] = str(input('Digite a sigla do estado: '))
    pais.append(estado.copy()) #O COPY substitui o '[:]' nos dicionários (para que haja uma cópia e não uma conexão dos mesmos)
for e in pais: #O 'e' vai percorrer as posições da Lista (3 posições de 0 a 2)
    for k, v in e.items(): #O 'k' vai percorrer as chaves (que agora estão em 'e', definido no FOR acima) e o 'v' vai mostrar os valores das respectivas chaves
        print(f'O campo {k} tem valor {v}')