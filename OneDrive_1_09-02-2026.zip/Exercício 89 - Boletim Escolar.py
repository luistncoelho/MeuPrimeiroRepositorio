#Exercício 89 - Boletim Escolar

print('----Exercício 89 - Boletim Escolar----')

temp = []
dados = []
iniciar = ' '
notas = ' '
while iniciar not in 'S/N':
    iniciar = input('Deseja iniciar a tabela de médias [S/N]? ').upper()
    if iniciar == 'S':
        while True:
            print('-'*50)
            temp.append(str(input('Digite o nome do aluno: ')))
            n1 = float(input('Digite o valor da N1: '))
            n2 = float(input('Digite o valor da N2: '))
            media = (n1+n2)/2
            temp.append(n1)
            temp.append(n2)
            temp.append(media)
            dados.append(temp[:])
            temp.clear()
            print('-'*50)
            continuar = input('Deseja continuar [S/N]? ').upper()
            if continuar == 'N':
                break
        print('-'*50)
        print(f'{"Nº":<5}',f'{"NOME":<35}',f'{"MÉDIA":^7}')
        print('-'*50)
        for c in dados:
            print(f'{(dados.index(c)+1):<5}',f'{c[0]:<35}',f'{c[3]:^7.1f}')
        print('-'*50)
        while notas not in 'S/N':
            notas = input('Você deseja visualizar as notas de algum(a) aluno(a) [S/N]? ')
            if notas == 'S':
                while True:
                    maisnotas = ' '
                    print('-'*50)
                    aluno = int(input('Digite o número do(a) aluno(a) para visualizar as suas notas: '))
                    print('-'*50)
                    print(f'As notas do(a) aluno(a) {dados[aluno-1][0]} são: N1 = {dados[aluno-1][1]} e N2 = {dados[aluno-1][2]}')
                    print('-'*50)
                    maisnotas = input('Deseja visualizar mais notas [S/N]? ').upper()
                    if maisnotas == 'N':
                        print('-'*50)
                        print('Você saiu do programa.')
                        break
    else:
        print('Você saiu do programa.')