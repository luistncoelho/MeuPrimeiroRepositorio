#Exercício 36 - Empréstimo Bancário (Com Condições Aninhadas)

valor = float(input('Qual o valor da casa? '))
salario = float(input('Qual o seu salário atual? '))
tempo = float(input('Em quantos meses pretende pagar? '))

prestação = float(valor/tempo)

if prestação > ((salario*30)/100):
    print('O empréstimo foi negado porque o valor da parcela excede 30% do valor do seu salário atual.')
else:
    print('Parabéns, o seu empréstimo foi aceito. O valor da parcela será R${:.2f}.'.format(prestação))

print('FIM')