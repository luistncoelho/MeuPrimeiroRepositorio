# Exercício 73 - Tabela Campeonato Brasileiro

print('----Classificação Campeonato Brasileiro----')

tabela = 'Atlético-PR', 'Bahia', 'Flamengo', 'Botafogo', 'São Paulo', 'Cruzeiro', 'Atletico-MG', 'Bragantino', 'Palmeiras', 'Internacional', 'Fortaleza', 'Gremio', 'Vasco Da Gama', 'Criciúma', 'Juventude', 'Corinthians', 'Fluminense', 'EC Vitória', 'Atlético-GO', 'Cuiabá'

print('Os cinco primeiros colocados são:')
for pos in range(0, 5):
    print(tabela[pos])

print(' ')
print('Os quatro últimos colocados são:')
for pos in range(16, 20):
    print(tabela[pos])

print(' ')
print(f'Os times masculinos do Campeonato Brasileiro, em ordem alfabética, são: \n {sorted(tabela)}')

print(' ')
time = input('Digite o nome do seu time: ').strip().title()
print(f'A posição atual do {time} é: {tabela.index(time) + 1}ª')