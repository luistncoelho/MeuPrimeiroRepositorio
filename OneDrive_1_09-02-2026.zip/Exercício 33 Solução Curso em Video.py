#Exercício 33 - 3 números (Maior e Menor)

n1 = float(input('Digite o primeiro número: '))
n2 = float(input('Digite o segundo número: '))
n3 = float(input('Digite o terceiro número: '))

menor = n1 #Já coloca o n1 como a menor variável para a lógica do MENOR
maior = n1 #Já coloca o n1 como a maior variável para a lógica do MAIOR

if n2 < n1 and n2 < n3:
    menor = n2
if n3 < n1 and n3 < n2:
    menor = n3
#Verificando quem é o menor. Lembre-se que a variável "menor" já estava configurada para o N1.

if n2 > n1 and n2 > n3:
    maior = n2
if n3 > n1 and n3 > n2:
    maior = n3

print('{} é o maior e {} é o menor.'.format(maior, menor))

print('FIM')