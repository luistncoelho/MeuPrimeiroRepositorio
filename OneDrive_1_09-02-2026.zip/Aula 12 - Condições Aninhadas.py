#Aula 12 - Condições Aninhadas

print('#EXEMPLO COM ESTRUTURA SIMPLES (SEM O ELSE)')

nome = input('Digite o seu nome: ').capitalize()

if nome == 'Luís':
    print('Que nome lindo!')
print('Tenha um ótimo dia, {}.'.format(nome))

print('-'*50)

#EXEMPLO COM ESTRUTURA COMPOSTA (COM O ELSE)
print('##EXEMPLO COM ESTRUTURA COMPOSTA (COM O ELSE)')

nome = input('Digite o seu nome: ').capitalize()

if nome == 'Luís':
    print('Que nome lindo!')
else:
    print('Pensei que o seu nome fosse Luís.')

print('Tenha um ótimo dia, {}.'.format(nome))

print('-'*50)

#EXEMPLO COM ESTRUTURA ANINHADA
print('##EXEMPLO COM ESTRUTURA ANINHADA')

nome = input('Digite o seu nome: ').capitalize()

if nome == 'Luís':
    print('Que que bom que você chegou, {}.'.format(nome))

elif nome == 'Fernanda': #O ELIF adiciona (aninha) mais uma condição ao IF original
    print('Que bom tê-la conosco, {}.'.format(nome))

else: #O ELSE Fecha as condições
    print('Ah, achei que fosse o Luís ou a Fernanda. Entre {}.'.format(nome))

print('Tenha um ótimo dia!')

print('-'*50)

#EXEMPLO COM ESTRUTURA ANINHADA + OR (Lógico)
print('##EXEMPLO COM ESTRUTURA ANINHADA + OR (Lógico)')

nome = input('Digite o seu nome: ').capitalize()

if nome == 'Luís':
    print('Que que bom que você chegou, {}.'.format(nome))

#O ELIF adiciona (aninha) mais uma condição ao IF original e o 'OR' adiciona mais condições no mesmo IF ou ELIF
elif nome == 'Fernanda' or nome == 'Maria' or nome == 'Ana':
    print('Que bom tê-la conosco, {}.'.format(nome))

else: #O ELSE Fecha as condições
    print('Ah, achei que fosse o Luís ou a Fernanda. Entre {}.'.format(nome))

print('Tenha um ótimo dia!')

print('-'*50)

#EXEMPLO COM ESTRUTURA ANINHADA + IN (Contém)

print('#EXEMPLO COM ESTRUTURA ANINHADA + IN (Contém)')

nome = input('Digite o seu nome: ').capitalize()

if nome == 'Luís':
    print('Seja bem vindo, {}.'.format(nome))

#O comando IN significa: A variável (nome) está contida em ____? (neste caso contida em "Luís Coelho"?)
elif nome in 'Luís Coelho':
    print('Seja bem vindo, Sr. {}.'.format(nome))

else:
    print('Seja bem vindo, {}.'.format(nome))

print('-'*50)