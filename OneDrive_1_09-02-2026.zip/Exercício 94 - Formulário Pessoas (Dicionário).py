#Exercício 94 - Formulário Pessoas (Dicionário)

print('----Exercício 94 - Formulário Pessoas (Dicionário)----')

def lin():
    print('-'*100)


form = list()
temp = dict()
mulheres = list()
idade = 0

while True:
    temp['Nome'] = str(input('Digite o nome da pessoa: ')).strip().upper()
    sexo = ' '
    while sexo not in 'M/F':
        sexo = str(input('Digite o sexo da pessoa [M/F]: ')).upper()
    temp['Sexo'] = sexo
    if temp['Sexo'] == 'F':
        mulheres.append(temp['Nome'])
    temp['Idade'] = int(input('Digite a idade da pessoa: '))
    idade += temp['Idade']
    form.append(temp.copy())
    continuar = ' '
    while continuar not in 'S/N':
        continuar = input('Deseja continuar a inserir pessoas [S/N]? ').upper()
    if continuar == 'N':
        break
media = idade/len(form)
lin()

print(f'Pessoas cadastradas: {len(form)}')
print(f'Média de idade do grupo: {media}')
print(f'Quantidade de mulheres cadastradas: {len(mulheres)}')
print(f'As mulheres cadastradas foram:')
for m in mulheres:
    print(f'- {m}')
lin()
print('Lista de Pessoas com idade acima da média: ')
for c in form:
    print(' ')
    if c['Idade'] > media:
        for k, v in c.items():
            print(f'{k} = {v};', end=' ')

lin()
print(form)