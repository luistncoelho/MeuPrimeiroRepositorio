#Exercício 53 - Detector de Palíndromos

palavra = input('Digite a palavra/expressão desejada para saber se é um Palíndromo: ').strip().upper()
# o STRIP tirará os espaços antes e depois (caso tenha), e o UPPER joga tudo para maiúscula.

semespacos = palavra.replace(' ','')
#Remove os espaços por nenhum caractér (note que há 'UM ESPAÇO' nas primeiras aspas).

qtd = len(semespacos) #Conta todos os caracteres da palavra sem os espaços

naoe = 0 #Esta variável será utilizada como contador do IF para posterior comparação

for letra in range (0, qtd): #O FOR contará a QTD de letras
    if semespacos[letra] != semespacos[(qtd-1)-letra]: #Compara (com DIFERENTE "!=") as posições (0 com ùltima, 1 com última-1, 2 com última -2, e assim por diante)
        naoe += 1
if naoe == 0:
    print('Esta palavra/expressão é um Palíndromo.')
else:
    print('Esta palavra/expressão NÃO é um Palíndromo.')

print('FIM')