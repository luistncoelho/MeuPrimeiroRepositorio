#EXERCÍCIO 90 - Média e Situação do Aluno

print('----EXERCÍCIO 90 - Média e Situação do Aluno----')

alunos = dict()
turma = list()
iniciar = ' '
continuar = ' '
while iniciar not in 'SN':
    iniciar = input('Deseja iniciar a inserção dos dados [S/N]? ').upper()
    if iniciar == 'S':
        while True:
            continuar = ' '
            alunos['nome'] = str(input('Digite o nome do aluno: '))
            alunos['media'] = float(input(f'Digite a média do aluno {alunos["nome"]}: '))
            if alunos['media'] >= 7:
                print(f'O aluno {alunos["nome"]} está APROVADO.')
                alunos['situação'] = 'APROVADO(A)'
            else:
                print(f'O aluno {alunos["nome"]} está REPROVADO.')
                alunos['situação'] = 'REPROVADO(A)'
            turma.append(alunos.copy())
            while continuar not in 'SN':
                continuar = input('Deseja continuar [S/N]? ').upper()
            if continuar == 'N':
                for c in turma: #O 'c' vai iterar (percorrer) a turma (nas posições).
                    name, average, situation = c.values()  # Cria 3 variáveis para receber as chaves dos dicionários. O 'values' vai jogar os dados nestas variáveis. O 'c' itera (percorre) e busca os valores 'c.values'.
                    print(f'O(a) aluno(a) {name} possui média {average} e está {situation}')
                print(f'A sua turma é: {turma}')
                print('Programa finalizado.')
                break

    else:
        print('Programa finalizado.')