print('Olá, Mundo!')


