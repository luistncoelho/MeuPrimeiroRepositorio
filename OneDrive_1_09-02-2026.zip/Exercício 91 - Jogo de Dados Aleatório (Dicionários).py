#xercício 91 - Jogo de Dados Aleatório (Dicionários)

print('----Exercício 91 - Jogo de Dados Aleatório (Dicionários)----')

import random
import time
from operator import itemgetter #o Itemgetter vai buscar os valores dentro das chaves do dicionário (Servirá para a ordenação)


jogadores = dict()
jogadores['jogador1'] = random.randint(1, 6)
jogadores['jogador2'] = random.randint(1, 6)
jogadores['jogador3'] = random.randint(1, 6)
jogadores['jogador4'] = random.randint(1, 6)
posição = 0

for j, n in jogadores.items():
    print(f'O {j} tirou o número {n}')

print('-='*50)
print('Ranking dos Jogadores')

for ordem, numero in sorted(jogadores.items(), key=itemgetter(1), reverse=True):
    posição += 1
    print(f'{posição}º lugar: {ordem}, com o número {numero}')
    #O 'sorted' vai ordenar os itens (chaves e valores) dentro do dicionário, porém, ordenará por chaves e não por valores (que é o que precisamos)
    #O 'key=itemgetter(1)' vai buscar a ordenação pelos valores(1) e não pelas chaves (que é o que precisamos).
    #O 'reverse=True' inverterá a ordenação (do maior para o menor).