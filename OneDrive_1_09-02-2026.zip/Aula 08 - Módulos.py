#Aula 08 (módulos/bibliotecas)
import math
num = int(input('Digite um número: '))
raiz = math.sqrt(num)
print('A raiz de {} é igual a {}'.format(num, raiz))
print()

print('#Biblioteca MATH - RAIZ com ARREDONDAMENTO PARA CIMA')
import math
num = int(input('Digite um número: '))
raiz = math.sqrt(num)
print('A raiz, arredondada para cima, de {} é igual a {}'.format(num, math.ceil(raiz)))
print()

print('#Biblioteca MATH - Importação somente de uma função - Exemplo: Raiz e Arredondamento para baixo - Utiliza menos memória')
from math import sqrt, floor
num = int(input('Digite um número: '))
raiz = sqrt(num)
print('A raiz, arredondada para baixo, de {} é igual a {}'.format(num, floor(raiz)))
print()

