#Exercício 69 - Idade e Sexo com 2 Laços Infinitos

print('----Exercício 69 - Idade e Sexo----')

qtd18 = 0
homens = 0
mulheres20 = 0
continuar = 0

while True:
    sexo = input('Digite o sexo da pessoa [M / F]: ').strip().upper()[0]
    idade = int(input('Digite a idade da pessoa: '))
    print('-'*100)
    if idade >= 18:
        qtd18 += 1
    if sexo == 'M':
        homens += 1
    if idade < 20 and sexo == 'F':
        mulheres20 += 1
    while True:
        continuar = str(input('Deseja continuar [S / N]: ')).strip().upper()[0]
        print('-' * 100)
        if continuar == 'S' or continuar == 'N':
            break
    if continuar == 'N':
        break

print(f'A quantidade de maiores de 18 anos é igual a {qtd18} pessoas'
      f'\nA quantidade de homens é igual a {homens}'
      f'\nA quantidade de mulheres com menos de 20 anos é {mulheres20}')
