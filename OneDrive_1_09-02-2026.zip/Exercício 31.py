#Exercício 31 - Preço da Passagem

distância = float(input('Digitea distância da sua viagem (em Km): '))

if distância <= 200:
    print('O preço da sua passagem é: R${:.2f}.'.format(distância*0.50))
else:
    print('O preço da sua passagem é: R${:.2f}.'.format(distância*0.45))

print('FIM')

