#EXERCÍCIOS 16 ao 21

print('#Exercício 16 - Porção Inteira do Número Real - Função TRUNC')
import math
n = float(input('Digite um número com decimais: '))
print('A parte inteira do número digitado é: {}'.format(math.trunc(n)))
print('-'*50)


print('#Exercício 17 - Cálculo da Hipotenusa')
from math import hypot
catOpo = float(input('Digite o valor do cateto oposto: '))
catAdj = float(input('Digite o valor do cateto adjacente: '))
hypot = float(hypot(catOpo, catAdj))
print('O valor da Hipotenusa é: {:.3f}'. format(hypot))
print('-'*50)


print('#Exercício 18 - Seno / Cosseno / Tangente - Com Conversão de Ângulo para Radianos')
import math
n = float(input('Digite o valor do ângulo: '))
grau = float(math.radians(n))
sen = float(math.sin(grau))
cos = float(math.cos(grau))
tang = float(math.tan(grau))
print('O seno do ângulo {:.1f} é: {:.2f} \nO cosseno do ângulo {:.1f} é {:.2f} \nA tangente do ângulo {:.1f} é {:.2f}'
        .format(n,sen,n,cos,n,tang))
print('-'*50)


print('#Exercício 19 - Sorteando Alunos - Função RANDOM e RANDOM.CHOICE')
import random
nome1 = str(input('Digite o nome do primeiro aluno: '))
nome2 = str(input('Digite o nome do segundo aluno: '))
nome3 = str(input('Digite o nome do terceiro aluno: '))
nome4 = str(input('Digite o nome do quarto aluno: '))
alunos = nome1, nome2, nome3, nome4
resultado = random.choice(alunos)
print('O aluno sorteado foi: {}'.format(resultado))
print('-'*50)


print('#Exercício 20 - Sorteando Alunos em Ordem - Função RANDOM e RANDOM.SAMPLE')
# O RANDOM.SHUFFLE também embaralharia os nomes, porém com o SAMPLE, dá para limitar a quantidade que será embaralhada
import random
nome1 = str(input('Digite o nome do primeiro aluno: '))
nome2 = str(input('Digite o nome do segundo aluno: '))
nome3 = str(input('Digite o nome do terceiro aluno: '))
nome4 = str(input('Digite o nome do quarto aluno: '))
alunos = nome1,nome2,nome3,nome4
resultado = random.sample(alunos,4)
print('Os sorteados foram: ', resultado)