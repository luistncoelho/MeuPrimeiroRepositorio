#Exercício 103 - Jogador e Gols com Doc Strings e Parâm Opcionais

print('----Exercício 103 - Jogador e Gols com Doc Strings e Parâm Opcionais----')

def estatistica(n='', g=''):
    jogador = n
    total_gols = g
    if n == '':
        jogador = '<desconhecido>'
    if g == '':
        total_gols = 0
    return(f'O jogador {jogador} fez um total de {total_gols} gols no campeonato.')

nome = str(input('Digite o nome do jogador: ')).title()
gols = input('Digite a quantidade total de gols no campeonato: ')
print(estatistica(nome, gols))