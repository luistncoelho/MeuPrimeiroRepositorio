#Exercício 96 - Área do Terreno (Função)

print('----Exercício 96 - Área do Terreno (Função)----')

def area(l, c):
    a = l * c
    print(f'A área do terreno de {l}m x {c}m é igual a: {a}m²')
    print('-'*100)


print('TESTE - Terreno com 10m x 25m')
area(10, 25)

print('TESTE - Terreno com 30m x 25m')
area(30, 25)

largura = float(input('Digite a largura do terreno (m): '))
comprimento = float(input('Digite o comprimento do terreno (m): '))

area(largura, comprimento)