#Exercício 84 - Nome e Peso de Pessoas

print('----Exercício 84 - Nome e Peso de Pessoas----')

nome = list()
peso = list()
dados = list()
maispesado = list()
maisleve = list()
cont = 0
maior = 0
menor = 0

iniciar = str(input('Dseja iniciar a tabela [S/N]: ')).upper()
if iniciar == 'S':
    cont += 1
    dados.append(str(input('Digite o nome da pessoa: ')))
    dados.append(float(input('Digite o peso da pessoa: ')))
    maior = dados[1]
    menor = dados[1]
    continuar = ' '
    while continuar not in 'SN':
        continuar = str(input('Deseja inserir mais dados [S/N]? ')).upper()
        if continuar == 'S':
            while True:
                cont += 1
                dados.append(str(input('Digite o nome da pessoa: ')))
                dados.append(float(input('Digite o peso da pessoa: ')))
                continuar = ' '
                while continuar not in 'SN':
                    continuar = str(input('Deseja inserir mais dados [S/N]? ')).upper()
                if continuar == 'N':
                    break
    for c in range(0, len(dados)):
        if c % 2 == 0:
            nome.append(dados[c])
        else:
            peso.append(dados[c])
            if dados[c] >= maior:
                maior = dados[c]
            elif dados[c] <= menor:
                menor = dados[c]
    for c in range(0, len(peso)):
        if peso[c] == maior:
            maispesado.append(nome[c])
            maispesado.append(peso[c])
        elif peso[c] == menor:
            maisleve.append(nome[c])
            maisleve.append(peso[c])
    print('-+'*50)
    print(f'Foram {cont} pessoas cadastradas.')
    print('-+'*50)
    vizumais = 'S'
    while vizumais == 'S':
        escolha = ' '
        escolha = int(input('Agora, diga o que deseja vizualizar?'
                            '\n(1) Lista geral de dados.'
                            '\n(2) Lista dos nomes.'
                            '\n(3) Lista dos pesos.'
                            '\n(4) Lista das pessoas com maior peso.'
                            '\n(5) Lista das pessoas com menor peso.'
                            '\nDigite a opção desejada: '))
        if escolha == 1:
            print(f'A lista geral é: {dados}')
        elif escolha == 2:
            print(f'A lista com os nomes é: {nome}')
        elif escolha == 3:
            print(f'A lista com os pesos é: {peso}')
        elif escolha == 4:
            print(f'A lista com as pessoas de maior peso é: {maispesado}')
        elif escolha == 5:
            print(f'A lista com as pessoas de menor peso é: {maisleve}')
        print('-+'*50)
        vizumais = input('Deseja vizualizar mais dados [S/N]? ').upper()

print('OK. Você saiu do programa.')