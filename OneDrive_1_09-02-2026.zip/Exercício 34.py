#Exercício 34 - Aumento de Salários

salario = float(input('Digite o seu salário: '))

if salario > 1250:
    print('O aumento do salário será de 10%, sendo R${:.2f} e o seu novo salário será R${:.2f}. Parabéns!'.format
          ((salario*0.1),(salario*0.1)+salario))
else:
    print('O aumento do salário será de 15%, sendo R${:.2f} e o seu novo salário será R${:.2f}. Parabéns!'.format
          ((salario * 0.15), (salario * 0.15) + salario))

print('FIM')