#Exercício 99 - Descobre o Maior (com Função)

print('----Exercício 99 - Descobre o Maior (com Função)----')

from time import sleep

def maior(* num):
    cont = maior = 0
    print('-=' * 50)
    print('Analisando os valores passados: ')
    sleep(0.5)
    for c in num:
        print(f'{c}', end=' ')
        sleep(0.5)
        if cont == 0:
            maior = c
        else:
            if c > maior:
                maior = c
        cont +=1
    print()
    print(f'Foram informados {cont} valores ao todo.')
    print(f'O maior valor informado é {maior}.')



#programa principal

maior(2, 9, 4, 5, 7, 1)
maior(4, 7, 0)
maior(1, 2)
maior(6)
maior(0)