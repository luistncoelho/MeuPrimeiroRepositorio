#Exercício 72 - Números por Extenso

print('----Exercício 72 - Números por Extenso----')

num = 'Zero', 'Um', 'Dois', 'Três', 'Quatro', 'Cinco', 'Seis', 'Sete', 'Oito', 'Nove', 'Dez','Onze', 'Doze',\
      'Treze', 'Quatorze', 'Quinze', 'Dezesseis', 'Dezessete', 'Dezoito', 'Dezenove', 'Vinte'

while True:
    print('-'*100)
    usu = int(input('Digite um número entre 0 e 20: '))
    while 0 > usu or usu > 20:
        usu = int(input('Tente novamente. O número deve estar entre 0 e 20: '))
    print(f'O número digitado por extenso é: {num[usu]}')
    continuar = ' '
    while continuar not in 'SN':
        print('-'*100)
        continuar = input('Deseja Continuar? ').strip().upper()[0]
    if continuar == 'N':
        break

print('Você saiu do programa.')
