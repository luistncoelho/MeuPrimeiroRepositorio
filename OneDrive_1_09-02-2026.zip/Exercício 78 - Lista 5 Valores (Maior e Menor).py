#Exercício 78 - Lista 5 Valores (Maior e Menor)

print('EXERCÍCIO 78 - Lista 5 Valores (Maior e Menor)')

maior = 0
menor = 0

n1 = int(input('Digite o primeiro número: '))
maior = n1
menor = n1
n2 = int(input('Digite o segundo número: '))
if n2 > maior:
    maior = n2
if n2 < menor:
    menor = n2
n3 = int(input('Digite o terceiro número: '))
if n3 > maior:
    maior = n3
if n3 < menor:
    menor = n3
n4 = int(input('Digite o quarto número: '))
if n4 > maior:
    maior = n4
if n4 < menor:
    menor = n4
n5 = int(input('Digite o quinto número: '))
if n5 > maior:
    maior = n5
if n5 < menor:
    menor = n5

lista = [n1, n2, n3, n4, n5]

print(f'A Lista digitada foi: {lista}')
print(f'O maior número digitado foi {maior} e suas posições são', end=' ')

for pos, c in enumerate(lista):
    if c == maior:
        print(pos, end=' ')

print(f'\nO menor número digitado foi {menor} e suas posições são', end=' ')

for pos, c in enumerate(lista):
    if c == menor:
        print(pos, end=' ')