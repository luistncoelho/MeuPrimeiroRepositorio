#Exercício 88 - Mega Sena

print('----Exercício 88 - Mega Sena----')

from random import sample #O SAMPLE já cria uma lista em um determinado range de números e com uma determinada quantidade. SEM REPETIR NÚMEROS!!!
import time

n = 0
qtd = int(input('Quantos jogos você deseja fazer? '))
listageral = list()

print(f'-------SORTEANDO {qtd} JOGOS-------')
for c in range(0, qtd):
    lista = sample(range(1, 61), 6) #Cria a lista entre 1 e 60, com 6 valores. O SAMPLE não repete números!!!!!
    lista.sort()
    print(f'Jogo {c+1}: {lista}')
    listageral.append(lista[:]) #Cria uma cópia da LISTA para a LISTAGERAL (sem criar a "conexão")
    lista.clear()
    time.sleep(1) #Faz o PYTHON demorar SEGUNDOS (1) antes do próximo comando.
print(f'Lista de Jogos: {listageral}')
print('-------BOA SORTE!!!-------')
