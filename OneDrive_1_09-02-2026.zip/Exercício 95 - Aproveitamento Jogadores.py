# Exercício 95 - Aproveitamento Jogadores

print('----Exercício 95 - Aproveitamento Jogadores----')


def lin():
    print('-=' * 100)


temp = dict()
aprov = list()
listgols = list()
iniciar = ' '
while iniciar not in 'S/N':
    iniciar = str(input('Deseja iniciar a tabela de aproveitamento [S/N]? ')).strip().upper()
    if iniciar == 'S':
        while True:
            continuar = ' '
            gols = 0
            totalgols = 0
            temp['Nome'] = str(input('Digite o nome do jogador: ')).strip().title()
            temp['Partidas'] = int(input(f'Quantas partidas {temp["Nome"]} jogou? '))
            lin()  # Chama a função 'lin' (criada para evitar a repetição do código 'print('-'*100). No ínicio do código.
            for c in range(0, temp['Partidas']):
                gols = int(input(f'Quantos gols {temp["Nome"]} na partida {c + 1}? '))
                listgols.append(gols)
                totalgols += gols
            temp['Gols'] = listgols[:]  # CRIA UMA CÓPIA DA LISTA DE GOLS, E NÃO A 'CONEXÃO'
            listgols.clear()  # LIMPA A LISA DE GOLS PARA O PRÓXIMO JOGADOR
            temp['Total de Gols'] = totalgols
            temp['Média de Gols'] = totalgols / (temp['Partidas'])
            aprov.append(temp.copy())
            temp.clear()
            lin()
            while continuar not in 'S/N':
                continuar = str(input('Deseja inserir os dados de outro jogador [S/N]? ')).strip().upper()
            lin()
            if continuar == "N":
                break
        print(aprov)
        lin()
        print('TABELA DE APROVEITAMENTO')
        print(f'{"Cód":<5}{"Nome":<15}{"Partidas":^15}{"Gols":<20}{"Total de Gols":^15}{"Média de Gols":^15}')
        lin()
        for p, c in enumerate(aprov):
            print(f'{p + 1:<5}', end='')
            name, matches, goals, total, average = c.values()
            print(f'{name:<15}{matches:^15}{str(goals):<20}{total:^15}{average:^15.2}')  # em 'GOALS', alteramos a variável para string, pois como 'lista' ela não deixa ser formatada

            #### LINHAS DE COMANDO DA RESOLUÇÃO DO CURSO EM VÍDEO (ABAIXO). Essas linhas trazem o resultado, porém sem a formatação que EU desejava.
            # for v in c.values():
            # print(f'{str(v):<15}', end='')
            # print(' ')
        lin()
        visu = ' '
        while visu not in 'S/N':
            visu = str(input('Deseja visualizar os jogos de algum jogador [S/N}? ')).strip().upper()
            lin()
            if visu == 'S':
                while True:
                    outrojogador = ' '
                    numjogador = int(input('Digite o número do jogador que deseja visualizar (de acordo com a tabela): '))
                    while True:
                        if (numjogador-1) < 0 or (numjogador-1) > (len(aprov)-1):
                            numjogador = int(input('Este número de jogador não exite na tabela. Digite um número válido: '))
                        else:
                            break
                    aprovjogador = aprov[numjogador-1]
                    lin()
                    print(f'DETALHAMENTO DO APROVEITAMENTO DO JOGADOR {aprovjogador["Nome"]}')
                    print(' ')
                    for p, g in enumerate(aprovjogador['Gols']):
                        print(f'{"=>":>5}', f'Na partida {p + 1}: {g} gols')
                    while outrojogador not in 'S/N':
                        lin()
                        outrojogador = str(input('Deseja visualizar outro jogador [S/N]? '))
                        lin()
                    if outrojogador == 'N':
                        break
