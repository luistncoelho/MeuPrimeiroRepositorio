#Exercício 102 - Fatorial com DOC STRINGS (Função)

print('----Exercício 102 - Fatorial com DOC STRINGS (Função)----')


def fatorial(n, show='NÃO'):
    """
    ---> Calcula o Fatorial do Número Escolhido
    ---> Mostra o Processo do Cálculo do Fatorial (Opcional)
    :param n: número do Fatorial
    :param show: (opcional) Demonstra o cálculo
    :return: O valor do Fatorial de um número n
    """
    fat = 1
    for c in range(1, n + 1):
        fat *= c
    if show == 'SIM':
        cont = 1
        while cont < n:
            print(cont,' x ', end=' ')
            cont += 1
        return(f'{n} = {fat}')
    else:
        return(f'O Fatorial de {n} é igual a: {fat}')

num = int(input('Digite o número desejado: '))
escolha = str(input('Deseja verificar o processo (Sim / Não): ')).upper()
print(fatorial(num, escolha))

print('-='*50)
help(fatorial)
