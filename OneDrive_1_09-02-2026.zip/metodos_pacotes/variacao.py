#Exercício 107 - Métodos (Funções) para Funções Financeiras Básicas


def aumentar(n=0, a=0):
    aumento = (n*(a/100))+n
    return aumento


def diminuir(n=0, a=0):
    reducao = n-(n*(a/100))
    return reducao


def dobrar(n=0):
    dobro = n*2
    return dobro


def metade(n=0):
    met = n/2
    return met