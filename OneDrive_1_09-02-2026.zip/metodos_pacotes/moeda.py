#Exercício 108 - Método (Função) para formatar Moeda em Reais.

from metodos_pacotes import variacao


def valor(n):
    return (f'R${n:.2f}')


def aumentar(n, a):
    return (f'R${variacao.aumentar(n, a):.2f}')


def diminuir(n, a):
    return (f'R${variacao.diminuir(n, a):.2f}')


def dobrar(n):
    return (f'R${variacao.dobrar(n):.2f}')


def metade(n):
    return (f'R${variacao.metade(n):.2f}')