#Exercício 46 - Comando FOR - Contagem Regressiva com Fogos de Artifício e Esperando 1s

import emoji as emoji

import time #importa a Biblioteca TIME (para a espera do tempo de 1s)

for c in range (10,0, -1):
    print(c)
    time.sleep(1) #O SLEEP faz o Python esperar x segundos para o próximo comando (aqui, 1 segundo)

print(emoji.emojize('Feliz Ano Novo!!!:fireworks:'))