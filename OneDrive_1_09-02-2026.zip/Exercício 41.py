#Exercício 41 - Idade Natação

print('#Exercício 41 - Idade Natação')

from datetime import date

anonasc = int(input('Digite o ano do seu nascimento: '))
data = date.today()
anoatual = data.year
idade = anoatual - anonasc

if idade <= 9:
    print('Você tem {} anos. Está na categoria MIRIM.'.format(idade))
elif idade > 9 and idade <= 14:
    print('Você tem {} anos. Está na categoria INFANTIL.'.format(idade))
elif idade > 14 and idade <= 19:
    print('Você tem {} anos. Está na categoria JÚNIOR.'.format(idade))
elif idade > 19 and idade <= 20:
    print('Você tem {} anos. Está na categoria SENIOR.'.format(idade))
else:
    print('Você tem {} anos. Está na categoria MASTER.'.format(idade))

print('FIM')




