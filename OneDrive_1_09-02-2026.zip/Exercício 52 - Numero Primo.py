#Exercício 52 - Número Primo

n = int(input('Digite um número: '))
cont = 0

#Lembramos que os números primos só são divisíveis por eles mesmo ou por 1.
for c in range (2, n): #o 'N' determinará o limite do contador (o próprio número digitado), e fará com que o laço vá até o número anterior.
    if (n % c) == 0:
        cont += 1
        # O 'IF' fará a variável "cont" aumentar, caso o 'N' seja divisível por qualquer número...
        # ...que não seja 1 ou ele mesmo (essa condição determina se o número NÃO é primo)
        # NÃO escolhemos o RANGE iniciando em 1 porque todos os números (primos ou não) são divisíveis por 1 ou por eles mesmos.

if cont == 0: #Aqui, verificamos o total de resultados (dos restos) das divisões. Caso ZERO, o número é primo.
    print('O número \033[1;32m{}\033[m é primo.'.format(n))
else:
    print('O número \033[1;32m{}\033[m \033[1;31mNÃO\033[m é primo.'.format(n))

#Lembramos que todos os números já possuem 2 divisões resultando em restos ZERO (por 1 ou por eles mesmos).
#Por isso, o nosso RANGE foi de 2 até o N (lembrando que o Python repetirá até N-1)
#Caso a variável CONT seja MAIOR do que ZERO, saberemos que dentre 2 e um número antes do N, teremos alguma divisão...
#... que resultoou em resto ZERO, nos dizendo que o número NÃO É primo.