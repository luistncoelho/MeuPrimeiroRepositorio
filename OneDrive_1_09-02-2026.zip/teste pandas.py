import pandas

tabela = pandas.read_csv('produtos.csv')

print(tabela)

import time
import pyautogui

time.sleep(10)
print(pyautogui.position())