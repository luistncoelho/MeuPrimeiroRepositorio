#Exercício 101 - Voto Obrigatório (com Função)

print('----Exercício 101 - Voto Obrigatório (com Função)----')


def voto(idade):
    from datetime import date #Colocar a biblioteca dentro da função ajuda a economizar memória (pois só utiliza a biblioteca quando a função é acionada)
    ano_atual = date.today().year
    idade = ano_atual - ano_nasc
    if idade < 16:
        return(f'Com {idade} anos: NÃO VOTA')
    elif idade >= 65:
        return(f'Com {idade} anos: VOTO OPCIONAL')
    else:
        return(f'Com {idade} anos: VOTO OBRIGATÓRIO')

ano_nasc = int(input('Digite o ano do seu nascimento: '))
print(voto(ano_nasc))

