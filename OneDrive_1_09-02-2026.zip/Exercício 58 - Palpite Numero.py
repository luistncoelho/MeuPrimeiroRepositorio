#Exercício 58 - Palpite Número

import random

cont = 0
c = 0

while c == 0:
    cont += 1
    numcomput = random.randint(0, 5)
    numusuario = int(input('Digite um número inteiro de 0 a 5: '))
    if numusuario == numcomput:
        c += 1
    else:
        print('Você errou, o computador escolheu {}. Tente novamente.'.format(numcomput))
print('Parabéns, você ganhou! Você jogou {} vezes para acertar.'.format(cont))

print('FIM')




