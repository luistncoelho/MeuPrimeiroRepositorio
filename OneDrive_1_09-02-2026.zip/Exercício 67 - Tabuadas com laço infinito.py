#Exercício 67 - Tabuadas com laço infinito

print('----Exercício 67 - Tabuadas----')

c = 0
n = 0
tab = 0

while True:
    n = int(input('Digite o número para a sua tabuada: '))
    if n < 0:
        break
    else:
        for c in range (0, 11):
            tab = c * n
            print(f'{c} x {n} = {tab}')
            c += 1
    print('\n----Tabuadas----')

print('Você digitou um número menor do que ZERO. O programa foi finalizado.')