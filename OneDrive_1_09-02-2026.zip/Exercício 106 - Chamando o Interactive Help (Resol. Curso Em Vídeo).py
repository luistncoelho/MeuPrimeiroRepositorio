#Exercício 106 - Chamando o Interactive Help (resol. Curso em Vídeo)

print('----Exercício 106 - Chamando o Interactive Help (resol. Curso em Vídeo)----')
print('-='*50)

from time import sleep

c = ('\033[0m',         #0 - Sem cores
     '\033[0;29;41m',   #1 - Vermelho
     '\033[0;29;42m',   #2 - Verde
     '\033[0;29;44m',   #3 - Azul
     '\033[7;40m'       #4 - Branco (invertido com preto)
     )


def ajuda(com, cor=0):
    titulo(f"Acessando o Manual do Comando '{comando}'", 3)
    print(c[cor], end='')
    help(com)
    print(c[0], end='')
    sleep(2)

def titulo(msg, cor=0):
    tam = len(msg)
    print(c[cor], end='')
    print('~' * tam)
    print(msg)
    print('~' * tam)
    print(c[0], end='')
    sleep(1)

comando = ''
while True:
    titulo('SISTEMA DE AJUDA pyHELP', 2)
    comando = str(input('Função ou Biblioteca > '))
    if comando.upper() == 'FIM':
        break
    else:
        ajuda(comando, 4)
titulo('Até Logo!', 1)
