#Exercício 55 - Mario e Menor Peso

maior = 0
menor = 0

for p in range (0, 5):
    peso = float(input('Digite o seu peso (em Kg): '))
    if p == 0: #faz a condição caso seja o primeiro peso digitado (ajuda a colocar toda a lógica dentro do FOR)
        maior = peso
        menor = peso
    elif peso >= maior:
            maior = peso
    elif peso <= menor:
            menor = peso

print('O maior peso digitado foi {}Kg, e o menor peso digitado foi {}Kg.'.format(maior, menor))
