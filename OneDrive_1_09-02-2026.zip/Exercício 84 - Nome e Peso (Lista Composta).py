#Exercício 84 - Lista Composta

print('----Exercício 84 - Lista Composta----')


dados = list()
tabela = list()
maior = 0
menor = 0
continuar = ' '
maispesadas = list()
maisleves = list()
qtd = 0

dados.append(str(input('Digite o nome da pessoa: ')))
dados.append(float(input('Digite o peso da pessoa: ')))
maior = dados[1]
menor = dados[1]
tabela.append(dados[:])
dados.clear()
qtd += 1

while True:
    while continuar not in 'SN':
        continuar = input('Deseja continuar [S/N]? ').upper()
    if continuar == 'N':
        break
    else:
        dados.append(str(input('Digite o nome da pessoa: ')))
        dados.append(float(input('Digite o peso da pessoa: ')))
        tabela.append(dados[:])
        if dados[1] >= maior:
            maior = dados[1]
        elif dados[1] <= menor:
            menor = dados[1]
        dados.clear()
        qtd += 1
        continuar = ' '

print(f'A quantidade de pessoas inseridas foi {qtd}.')
print(f'As pessoas com maior peso são:',end=' ')
for c in tabela:
    if c[1] == maior:
        print(f'{c[0]}, com {c[1]}kg.',end=' ')

print(f'\nAs pessoas com menor peso são:', end=' ')
for c in tabela:
    if c[1] == menor:
        print(f'{c[0]}, com {c[1]}kg.',end=' ')

