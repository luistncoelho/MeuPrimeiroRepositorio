#Aula 20 - Funções (Parte 2)

print('Aula 20 - Funções (Parte 2)')

# TÓPICOS:
# 1) Interactive Help
# 2) Docstrings (Documentação das Funções)
# 3) Argumentos Opcionais
# 4) Escopo de Variáveis
# 5) Funções que retornam resultados (RETURN)

#--------------------------------------------------------------------------

# 1) INTERACTIVE HELP: Basta utilizar a função 'help()'. Digitar no "Python Console", ou Digitar
#o comando dentro dos parêntese do 'help()'. Serve para mostrar infos sobre as funções.
print('-='*100)
help(input)

#ou
print('-='*100)
print(input.__doc__) #Também mostra uma documentação da função (neste caso: "input")

#--------------------------------------------------------------------------

# 2) DOCSTRINGS (DOCUMENTAÇÃO DAS FUNÇÕES): É um "manual" da função.

# É utilizado para criar a Documentação das Funções que você mesmo cria.
# É acionado logo após o comando DEF (embaixo) e por 3 aspas duplas (""").
# É finalizado por 3 aspas duplas também.

#Exemplo da criação de uma documentação para uma função CONTADOR:
print('-='*100)
def contador(i, f, p):
    """
    -> Faz uma contagem e mostra na tela.
    :param i: início da contagem
    :param f: fim da contagem
    :param p: passo da contagem
    :return: sem retorno
    """
    c = i
    print('CONTADOR')
    while c <= f:
        print(c, end=' - ')
        c += p
    print('FIM!')

contador(0,10,2)
print('-='*100)

help(contador) #Vai exibir a documentação do CONTADOR (criado dentro da FUNÇÃO).
print('-='*100)
print('-='*100)

#--------------------------------------------------------------------------

# 3) ARGUMENTOS OPCIONAIS: É quando você define (através de "=") um padrão para uma variável
# dentro da sua função.

# EXEMPLO: Def somar(a, b, c=0)
# Aqui, a função vai entender que, caso o usuário não digite a
# variável 'c', ela será, como padrão, igual a 0. Pode-se determinar um valor padrão para qualquer
# variável, assim como para todas elas.

#--------------------------------------------------------------------------

# 4)ESCOPO DE VARIÁVEIS OU ESCOPO DE DECLARAÇÕES: É o local onde uma variável vai ou não existir

# ESCOPO GLOBAL: Quando a variável é definida "fora" da função. Funciona caso chamada dentro ou fora da função.
# ESCOPO LOCAL: Quando a variável é definida "dentro" da função. Neste caso, SOMENTE funcionará quando
#               chamada dentro da função!!!

#PAREI NO MINUTO 31:30