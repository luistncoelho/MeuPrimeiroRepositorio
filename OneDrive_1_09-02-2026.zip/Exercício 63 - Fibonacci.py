#Exercício 63 - Sequência Fibonacci

print('----Sequência Fibonacci----')

n = int(input('Digite o número de termos Fibonacci que você quer ver: '))
atual = 1
anterior = 0
fibonacci = 0
c = 1

print(anterior,'-', atual, end=' - ')

while c <= (n-2): #Utilizar o "n-2" porque os dois primeiros termos (0 e 1) já foram impressos acima.
    fibonacci = atual + anterior
    print(fibonacci, end=' - ')
    anterior = atual
    atual = fibonacci
    c += 1

print('\nFIM')

