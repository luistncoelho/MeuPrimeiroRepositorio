#Exercício 57 - Sexo Masculino ou Feminino

c = 1
while c == 1:
    sexo = input('Digite o seu sexo [M / F]: ').upper()
    if sexo == 'M' or sexo == 'F':
        c += 1
    else:
        print('Entrada inválida, digite M ou F.')
print('FIM')