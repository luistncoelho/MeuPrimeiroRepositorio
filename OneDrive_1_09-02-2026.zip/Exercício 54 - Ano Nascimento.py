#Exercício 54 - Ano de Nascimento (COntador de Pessoas)

from datetime import date

anoatual = date.today().year
maiores = 0
menores = 0

for c in range (0, 7):
    nascimento = int(input('Digite o Ano do seu nascimento: '))
    if (anoatual - nascimento) >= 21:
        maiores += 1
    else:
        menores += 1

print('O ano atual é {} e a quantidade de pessoas que atingiram a maioridade é {}.'.format(anoatual, maiores))
print('A quantidade de pessoas "menores" de 21 anos é {}.'.format(menores))

print('FIM')

