#Exercício 48 - Soma de todos os números ímpares múltiplos de 3

s = 0
cont = 0 #Variável criada para contar a quantidade de números

for c in range (1, 501, 2): #Até 501 porque o Python remove o último (501). De 2 em 2 para contar somente os ímpares (**começa no 1)
    if c % 3 == 0: #Condição para que o contador (C) considere somente os múltiplos de 3 (com resto = ZERO)
        s += c #soma da variável 'acumuladora' S com o contador (incremental)
        cont += 1
        print(c, end= ' ')

print('\nA soma de todos os {} números múltiplos de 3, entre 1 e 500, é igual a: \033[1;32m{}\033[m'.format(cont,s))
#o \033[1;32m insere a cor verde em Negrito. A sequência, \033[m fecha a alteração da cor.