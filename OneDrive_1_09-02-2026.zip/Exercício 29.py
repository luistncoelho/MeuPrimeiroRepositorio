#Exercício 29 - Radar Eletrônico

vel = float(input('Velocidade do carro: '))
excedido = float(vel - 80)
valorapagar = float(excedido*7)

if vel > 80:
    print('Você ultrapassou o limite de velocidade em {} Km/h. Sua multa é de R${:.2f}.'.format(excedido,valorapagar))

print('FIM')