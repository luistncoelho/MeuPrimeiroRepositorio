#Exercício 43 - IMC

print('#Exercício 43 - IMC')

peso = float(input('Digite o seu peso: '))
altura = float(input('Digite a sua altura: '))
imc = float(peso/(pow(altura,2)))

if imc < 18.5:
    print('O seu IMC é {:.1f}. Você está ABAIXO do peso.'.format(imc))
elif 18.5 <= imc < 25:
    print('O seu IMC é {:.1f}. Você está no peso IDEAL.'.format(imc))
elif 25 <= imc < 30:
    print('O seu IMC é {:.1f}. Você está com SOBREPESO.'.format(imc))
elif 30 <= imc < 40:
    print('O seu IMC é {:.1f}. Você está com OBESIDADE.'.format(imc))
else:
    print('O seu IMC é {:.1f}. Você está com OBESIDADE MÓRBIDA.'.format(imc))

print('FIM')