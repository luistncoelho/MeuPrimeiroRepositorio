#Aula 16 -  Tuplas (Variáveis Compostas)

#Variáveis compostas são: TUPLAS / LISTAS / DICIONÁRIOS

# TUPLAS são IMUTÁVEIS (não podem ser alteradas)!!!!
# TUPLAS utilizam PARÊNTESES!!!!!!
# A TUPLA pode receber diferentes tipos de dados
# Após o PYTHON 3.5, os parênteses deixaram de ser necessários nas tuplas. Porém, no resultado, os parênteses serão mostrados (para indicar a TUPLA)
# O COMANDO DEL () apaga qualquer tupla ou lista ou dicionário no PYTHON

# LISTAS utilizam COLCHETES

# DICIONÁRIOS utilizam CHAVES

lanche = ('pao', 'mortadela', 'suco', 'café')

print('-'*100)
print('----EXEMPLOS com Manipulação das Posições----')
print(len(lanche))
print(lanche[1:])
print(lanche[0:3]) #nunca mostra o último (café)
print(lanche[:3]) #mostrará do ZERO até o 2 (o último sempre é ignorado)
print(lanche[-1]) #inverte a lista (aqui, mostrará o café). O ZERO sai da numeração
print(lanche[-4]) #inverte a lista (aqui, mostrará o pao). O ZERO sai da numeração

print('-'*100)
print('---EXEMPLO 1 com o FOR---')
for c in lanche: # O FOR vai printar cada um dos elementos da Tupla. Pois a cada volta, o C recebe o próximo elemento.
    print(c)

print('-'*100)
print('---EXEMPLO 2 com o FOR e RANGE---')
for cont in range(0, len(lanche)): # Mostrará os números de posição dos elementos (de Zero à 3. São 4 lanches)
    print(cont)

print('-'*100)
print('---EXEMPLO 3 com o FOR e RANGE---')
for cont in range(0, len(lanche)):
    print(lanche[cont]) #Aqui, o PRINT procura o "NOME" do elemento de acordo com a posição estabelecida pelo CONTADOR do FOR.
    # O Resultado será igual ao do EXEMPLO 1 com FOR, porém aqui, nós utilizamos técnicas mais elaboradas (para problemas futuros)

print('-'*100)
print('---EXEMPLO 4 com o FOR - MOSTRANDO ELEMENTO E POSIÇÃO---')
for cont in range(0, len(lanche)):
    print(f'O {lanche[cont]} está na posição {cont}')
    #Aqui, o PRINT procura o "NOME" do elemento de acordo com a posição estabelecida pelo CONTADOR do FOR e o CONT mostra a posição.

print('-'*100)
print('---EXEMPLO 5 com o FOR e ENUMERATE- MOSTRANDO ELEMENTO E POSIÇÃO---')
for pos, cont in enumerate(lanche): #É necessário definir as duas variáveis (uma para a POSIÇÃO e uma para o ELEMENTO)
    print(f'O {cont} está na posição {pos}')
    #Aqui, o POS vai para o ENUMERATE, que retorna a POSIÇÃO do elemento, e o CONT, vai para o LANCHE, que retorna o ELEMENTO
    #Igual o EXEMPLO 4, porém com a FUNÇÃO ENUMERATE.

print('-'*100)
print('---EXEMPLO 6 com o SORTED (Colocar em ORDEM---')

print(sorted(lanche)) #ordenará em ordem alfabética

print('-'*100)
print('---EXEMPLO 7 - UNINDO TUPLAS---')

a = (2, 5, 4)
b = (30, 10, 20)
c = a + b   # Este comando cria uma variável que UNE as duas tuplas (a + b).
#Atenção, pois a ordem das tuplas (a+b) ou (b+a) altera a ordem da tupla final (c)

print(f'Tupla a = {a}')
print(f'Tupla b = {b}')
print(f'Tupla c (a + b) = {c}')
print(f'Tupla c (a + b) em ORDEM (com o SORTED) = {sorted(c)}')
#Comando PRINT com o 'f-string' e com o SORTED (para ordenar a tupla). Atenção no SORTED dentro das CHAVES do f-string!!!

print('-'*100)
print('---EXEMPLO 8 - ".COUNT" (Contando um ELEMENTO dentro da TUPLA)---')

tup1 = (2, 5, 4)
tup2 = (30, 10, 20, 2)
tup3 = a + b

print(c)
print(f'O número 2 aparece {tup3.count(2)} vezes.')
# o nome da TUPLA deve vir antes do ".COUNT" com o respectivo elemento dentro dos parênteses

print('-'*100)
print('---EXEMPLO 9 - ".INDEX" (Retorna a posição de um ELEMENTO dentro da TUPLA)---')

tupla1 = (2, 5, 4)
tupla2 = (30, 10, 20, 2)
tupla3 = tupla1 + tupla2

print(tupla3)
print(f'O número 2 aparece na posição {tupla3.index(2)}.')
# o nome da TUPLA deve vir antes do ".INDEX" com o respectivo elemento dentro dos parênteses
# o ".INDEX" sempre retornará a primeira ocorrência de posição do elemento, neste caso: posição = 0
# para receber outras posições do mesmo ELEMENTO, deve-se fazer uma referência à quando o código vai começar a procurar. Ver exemplo abaixo:

print(f'O número 2 aparece na posição {tupla3.index(2)}'
      f'\ne também na posição {tupla3.index(2, 1)}.')
    # Neste comando, o segundo .INDEX recebe um parâmetro após o ELEMENTO (1), este parâmetro é a indicação de qual posição o PYTHON deve começar a procurar o ELEMENTO
    # como sabemos que a primeira ocorrência do 2 foi na posição 0, indicamos para o programa começar a procurar novamente a partir da posição 1.


