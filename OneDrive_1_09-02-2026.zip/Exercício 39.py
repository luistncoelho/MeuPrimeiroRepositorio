#Exercício 39 - Ano de Alistamento (Com DATA do sistema)

print('#Exercício 39 - Ano de Alistamento (Com DATA do sistema)')

from datetime import date #BIBLIOTECA DATETIME (Para datas)

anonasc = int(input('Qual o ano do seu nascimento? '))
data = date.today() #Puxa a DATA de HOJE
anoatual = data.year #Através da data de hoje, puxa o ANO atual
idade = anoatual - anonasc


if idade < 18:
    print('Você tem {} anos. Faltam {} anos para você se alistar.'.format(idade, 18-idade))
elif idade == 18:
    print('Vocâ tem {} anos. Está na hora de se alistar.'.format(idade))
else:
    print('Você tem {} anos. Já passou {} anos do alistamento. Caso não tenha se alistado, favor procurar o posto\n'
          'Poupatempo mais próximo de você.'.format(idade, idade-18))

print('FIM')






