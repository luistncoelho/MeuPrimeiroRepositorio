#Aula 21 - Funções (Parte 1)

print('----Aula 21 - Funções (Parte 1)----')

#Funções representam ROTINAS na programação (você criar uma função para não ter que ficar repetindo rotinas sempre)

def mostralinha(): #'DEF' é o comando que define uma função. 'MOSTRALINHA' é o nome da nossa função.
    print('---------------------------------') #Esta é a parte na qual nós dizemos o que vai acontecer na função.

#OBS: é importante dar '2' espaços para separar as FUNÇÕES do programa principal
mostralinha() #Vai printar a nossa função sempre que nós precisarmos.

print('-='*50)
print('EXEMPLO DE PROGRAMA COM A FUNÇÃO "MOSTRALINHA"')

mostralinha()
print('          SISTEMA DE ALUNOS         ')
mostralinha()
print('       CADASTRO DE FUNCIONÁRIOS         ')
mostralinha()
mostralinha()
print('           ERRO DE SISTEMA          ')
mostralinha()

print('-='*50)
print('FUNÇÃO COM PARÂMETRO DENTRO DO PARÊNTESES')

def titulo(msg): #O que está dentro do parênteses será modificado na operação do código.
    print('-'*30)
    print(msg) #Aqui é o local onde a mensagem será alterada (deve ter o mesmo nome que foi definido acima, na função
    print('-'*30)

titulo('     Curso em Vídeo     ') #Esta mensagem entrará em todos os momentos que o parênteses '(msg)' foi definido na função
print('-------------ALTERANDO OS PARÂMETROS DENTRO DE UMA FUNÇÃO (Exemplo com soma)-------------')
titulo('        Aula 21         ')

print('-='*50)
mostralinha()
print('SEM FUNÇÃO')

a = 4
b = 5
s = a + b
print(s)

a = 8
b = 9
s = a + b
print(s)

#OBS: Os dois casos acima representa a mesma rotina de soma. Portanto, criaremos uma função para que não
#precisemos ficar copiando os códigos todas as vezes

print('-'*30)
print('COM FUNÇÃO')


def soma(a, b): #Aqui, criamos uma função com 2 parâmetros (a, b). Neste caso, sempre precisaremos colocar os 2 parâmetros.
    s = a + b #Aqui, dizemos o que faremos com os 2 parâmetros (a, b).
    print(f'A soma é igual a {s}') #Aqui, mostramos o resultado com o print


soma(4, 5) #Aqui, chamamos a função "SOMA" e passamos os parâmetros para o programa (a=4 e b=5).
soma(10, 15) #Mudamos os parâmetros
soma(13, 1) #Mudamos os parâmetros
soma(8, 9) #Mudamos os parâmetros

#OBS: Com isso, percebemos o quão útil são as funções. Ao invés de copiarmos o código com variáveis e lógica para cada
#uma das somas (são 4), somente a criamos uma vez (como uma função) e a chamamos sempre que precisamos.

print('-'*30)
print('EXPLICITANDO OS PARÂMETROS')

def soma2(a, b):
    print(f'A = {a} e B = {b}')
    s = a+b
    print(f'A soma é igual a {s}')

soma2(b=10, a=2) #Aqui, estamos explicitando o que será o parâmetro 'b' e o que será o parâmetro 'a', independentemente
#da ordem.
soma2(7, 2) #Como os parâmetros não foram explicitados (como acima), o A será 7 e o B será o 2.

#OBS: É importante lembrar que, como definimos 2 parâmetros na função, o PYTHON aceitará somente 2 valores. Nem mais, nem menos.

print('-'*30)
print('UTILIZANDO OS PARÂMETROS COM "EMPACOTAMENTO"')

def contador(*num): #O '*' (asterisco) cria uma tupla. Ou seja, a partir daí, você poderá digitar quantos valores quiser, quando chamar a função.
    print(num) #com isso, podemos trabalhar da mesma forma que trabalhamos com as tuplas (Utilizando FOR, LEN, etc...)


contador(2, 1, 7)
contador(8, 0)
contador(4, 4, 7, 6, 2)

print('-'*30)
print('UTILIZANDO OS PARÂMETROS COM "EMPACOTAMENTO" (COM FOR)')

def contadorfor(*num):
    for c in num:
        print(f'{c}', end=' ')
    print('\nFIM')

contadorfor(2, 1, 7)
contadorfor(8, 0)
contadorfor(4, 4, 7, 6, 2)

print('-'*30)
print('UTILIZANDO OS PARÂMETROS COM "EMPACOTAMENTO" (COM LEN)')

def contadorlen(*num):
    tam = len(num)
    print(f'Recebi os valores {num} e são, ao todo, {tam} números.')


contadorlen(2, 1, 7)
contadorlen(8, 0)
contadorlen(4, 4, 7, 6, 2)

print('-='*50)
print('---------FUNÇÃO COM LISTAS---------')

def dobra(lista): #Aqui, estamos criando uma FUNÇÃO fazendo referência à uma lista que será criado (olhar abaixo "VALORES").
    pos = 0 #criamos esta variável para termos como referência o início das posições da LISTA
    while pos < len(lista): #criamos o LOOP com WHILE que rodará até chegar ao final da lista
        lista[pos] *= 2 #fazemos que a POS (posição na lista) seja dobrada (*= 2)
        pos += 1 #faz com que o LOOP avance 1 posição na lista (incremento)

valores = [1, 2, 3, 4, 5] #Cria a lista de valores
dobra(valores) #Executa a função de dobra utilizando as posições da lista VALORES
print(f'O dobro dos valores da lista é igual a: {valores}')