#Exercício 62: Progressão Aritimética com Muitos Termos

print('----Progressão Aritmética (Muitos Termos)----')

primtermo = int(input('Digite o primeiro termo da sua progressão: '))
razao = int(input('Digite a Razão da sua progressão: '))
qtdtermos = int(input('Quantos termos você deseja? '))
prog = primtermo
listapa = [] #Inicia uma lista sem valores
novos = 0
continua = 'S'

while continua == 'S': #O WHILE está amarrado com o IF de continuação do programa.
    print(primtermo, end=' ') #Aqui o 1º termo já entra para que não se repita no FOR, e sim no WHILE.
    listapa = [primtermo] #Coloca o 1º termo na lista, sem ser repetido pelo FOR.
    for c in range (0,(qtdtermos-1)):  # O FOR rodará até a qtd de termos definida pelo usuário. O -1 é necessário porque o 1º termo já foi impresso no WHILE.
        prog += razao
        c += 1
        print(prog, end= ' ')
        listapa.append(prog) #Inclui o restante da PA na Lista
    prog = primtermo #Resseta a PA para apenas o 1º termo, caso o usuário deseje recalculá-la.
    continua = input('\nDeseja incluir mais termos [S / N]: ').upper() #Faz a pergunta da continuação.
    if continua == 'S': #Caso 'SIM', pedirá mais valores para a PA.
       novos = int(input('Quantos termos novos você gostaria de incluir? '))
       qtdtermos += novos #Incuirá os novos TERMOS à quantidade inicial de termos.
    else:
        print('Você finalizou o programa. Os termos da sua PA são: {}.'.format(listapa))
