#Exercício 82 - Lista Geral - Lista Par - Lista Ímpar COM FOR

print('----Exercício 82 - Lista Geral - Lista Par - Lista Ímpar - COM FOR----')

lista = []
listapar = []
listaimpar = []

while True:
    continuar = ' '
    n = int(input('Digite o número desejado: '))
    lista.append(n)
    while continuar not in 'SN':
        continuar = input('Deseja inserir outro número (S/N)? ').upper()
    if continuar == 'N':
        break

for c in range(0, len(lista)):
    if lista[c] % 2 == 0:
        listapar.append(lista[c])
    else:
        listaimpar.append(lista[c])

lista.sort()
listapar.sort()
listaimpar.sort()

print('-'*100)
print(f'A lista geral é: {lista}')
print(f'A lista com os números pares é: {listapar}')
print(f'A lista com os números ímpares é: {listaimpar}')

