#Exercício 106 - Chamando o Interactive Help (meus comandos para Cores)

print('----Exercício 106 - Chamando o Interactive Help (meus comandos para Cores)----')
print('-='*50)


def ajuda(com):
    print('\33[7;40m')
    return help(com)


def titulo(msg):
    tam = len(msg)
    if msg == 'SISTEMA DE AJUDA pyHELP':
        print('\33[1;29;42m~' * tam)
        print(msg)
        print('\33[1;29;42m~' * tam)
        print('\33[m')
    elif msg == 'Até Logo!':
        print('\33[1;29;41m~' * tam)
        print(msg)
        print('\33[1;29;41m~' * tam)
        print('\33[m')
    else:
        print('\33[1;29;44m~' * tam)
        print(msg)
        print('\33[1;29;44m~' * tam)
        print('\33[m')


comando = ''
while True:
    print('\33[m')
    titulo('SISTEMA DE AJUDA pyHELP')
    comando = str(input('\33[mFunção ou Biblioteca > '))
    if comando.upper() == 'FIM':
        break
    else:
        titulo(f"Acessando o Manual do Comando '{comando}'")
        ajuda(comando)
titulo('Até Logo!')