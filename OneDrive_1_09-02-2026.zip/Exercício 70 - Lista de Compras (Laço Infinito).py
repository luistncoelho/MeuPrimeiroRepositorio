#Exercício 70 - Lista de Compras com Laço Infinito

print('----Lista de Compras----')

import pandas as pd

produto = ''
preco = qtd = total = prod1000 = precobarato = primerpreco = 0 #Declara todas essas variáveis de uma vez (coloca o ZERO)
prodbarato = primerprod = continuar = '' #Declara todas essas variáveis de uma vez só.
lista_produtos = [] # Cria a lista de produtos (com LINHAS)
lista_precos = [] # Cria a lista de preços (com LINHAS)

iniciar = str(input('Deseja iniciar a compra [S / N]? ')).strip().upper()[0]

if iniciar == 'S':
    qtd += 1
    primerprod = str(input('Digite o nome do 1º produto: '))
    primerpreco = float(input('Digite o preço do 1º produto: '))
    total += primerpreco
    lista_produtos.append(primerprod)
    lista_precos.append(primerpreco)
    if preco > 1000:
        prod1000 += 1
    prodbarato = primerprod
    precobarato = primerpreco
    print('-'*100)

    while True:
        while True:
            continuar = str(input('Deseja inserir outro produto [S / N]? ')).strip().upper()[0]
            print('-' * 100)
            if continuar == 'S' or continuar == 'N':
                break
            #Poderia ter utilizado o WHILE ___ NOT IN '___' para criar este LAÇO (Como nos Exs. 68 e 69). Porém deixei assim para ter uma alternativa 'criativa'.

        if continuar == 'S':
            qtd += 1
            produto = str(input('Digite o nome do produto: '))
            preco = float(input('Digite o preço do produto: '))
            total += preco
            lista_produtos.append(produto) # Adiciona ao final da lista de produtos
            lista_precos.append(preco) # Adiciona ao final da lista de preços
            if preco > 1000:
                prod1000 += 1
            if preco < precobarato:
                precobarato = preco
                prodbarato = produto
            print('-'*100)
        else:
            break
    dados = {'Produtos': lista_produtos, 'Preços': lista_precos} #Cria um 'DICIONÁRIO' com as duas listas (com duas colunas: 'Produtos' e 'Preços')
    df = pd.DataFrame(dados) # O 'DATAFRAME' vair organizar os dados em uma tabela
    print(f'Você terminou as suas compras. Estes são os seus dados:\n'
          f'Quantidade de produtos comprados: {qtd}\n'
          f'Total da compra: R${total}\n'
          f'Quantidade de produtos que custam mais de R$1.000,00: {prod1000}\n'
          f'O produto mais barato da lista foi: {prodbarato}')
    print('-'*100)
    print(df)
    print('-' * 100)
    print(df.info())
else:
    print('Você saiu da planilha de compras. Muito obrigado!')

