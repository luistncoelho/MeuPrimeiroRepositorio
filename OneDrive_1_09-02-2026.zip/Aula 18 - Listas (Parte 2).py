#Aula 18 - Listas (Parte 2)

print('----Aula 18 - Listas (Parte 2)----')

lista = list() #cria uma lista comum
lista.append('Gustavo') #insere o "Gustavo" na lista
lista.append(40) #insere o 40 na lista
print(lista)

galera = list() #cria uma nova lisata comum
galera.append(lista) #insere toda a "LISTA" ['Gustavo', 40] para dentro da lista 'GALERA'.
#Neste caso, não houve apenas uma 'cópia' da LISTA para dentro da GALERA, houve uma 'conexão', ou seja
#tudo que for alterado na lista original (LISTA), será alterado na lista composta (GALERA).
print(galera)

#Alterando dados da lista original (LISTA) com a conexão:
lista[0] = 'Maria'
lista[1] = '15'
print(lista)
print(galera) #Aqui, veremos que o que foi alterado na LISTA, será alterado na GALERA.

galera.append(lista) #Aqui, conseguimos ver que a lista COMPOSTA (GALERA) não consegue manter os primeiros dados
#'Gustavo' e '40', pois como houve a 'conexão' de listas, ela sempre manterá os dados da lista original.
print(galera)

#Fazendo uma cópia sem conexão, para que a lista COMPOSTA seja atualizada de acordo com a lista ORIGINAL, mas
#mantenha um histórico de dados:

lista2 = list() #criamos uma nova lista original para efeito de teste
lista2.append('Gustavo')
lista2.append(40)
galera2 = list()
galera2.append(lista2[:]) #Agora nós criamos uma cópia da lista original, mas sem a conexão
print(lista2)
print(galera2)

#Agora, quando alterarmos um dado na lista original (LISTA2), o mesmo será adicionado na lista COMPOSTA (GALERA2)
#porém o histórico (dados antigos) será mantido na COMPOSTA.

lista2[0] = 'Maria' #alterando os dados da lista original
lista2[1] = 15

galera2.append(lista2) #Adicionando os dados alterados na lista COMPOSTA (GALERA2)

print(galera2) #Aqui poderemos ver que a lista COMPOSTA (GALERA2) terá duas entradas da lista original
#[['Gustavo', 40] , ['Maria', 15]].

#É importante lembrar que a lista COMPOSTA possui os seus próprios posicionamentos (como chaves), partindo do 0.

#EXEMPLO: Caso queiramos chamar a idade 15 da Maria, deveremos chamar: print(galera2[1][1])
#o primeiro 1 é o posicionamento na lista COMPOSTA ['MARIA', 15], e o segundo aprofunda o posicionamento e busca o dado na
#posição 1 desta chave.

print(galera2[1][1])

print('-='*50)
print('-='*50)

print('----CRIANDO UMA LISTA COMPOSTA COM VÁRIOS DADOS-----')

clientes = [['João', 19], ['Ana', 33], ['Joaquim', 13], ['Maria', 45]]
# Aqui há 4 chaves na lista composta (0, 1, 2, 3). Cada chave com dois tipos de dados (nome e idade)
# Perceba que há uma vírgula separando todas as "Chaves" da lista composta.
print(f'Clientes: {clientes}')

print('-='*50)
#EXEMPLO: Buscando dados da chave 2 (Joaquim, 13)
print('#EXEMPLO: Buscando dados da chave 2 (Joaquim, 13)')

print(f'Dados do cliente: {clientes[2]}')

#EXEMPLO: Buscando somente o nome da chave 2 (Joaquim)
print(f'Nome do cliente: {clientes[2][0]}')

#EXEMPLO: Buscando somente a idade da chave 2 (13)
print(f'Idade do cliente: {clientes[2][1]}')

print('-='*50)
print('-='*50)
print('----Mostrando os Dados com o FOR----')

for c in clientes: #O C vai rodar as CHAVES da lista composta (CLIENTES)
    print(c) # O C vai mostrar todos os dados das CHAVES (NOME E IDADE)

print('-='*50)
for c in clientes: #O C vai rodar as CHAVES da lista composta (CLIENTES)
    print(c[0]) # Aqui o programa lerá somente os nomes (pois ficou definido a posição 0 das chaves).

print('-='*50)
for c in clientes: #O C vai rodar as CHAVES da lista composta (CLIENTES)
    print(c[1]) #Aqui o programa lerá somente as idades (pois ficou definido a posição 1 das chaves).

print('-='*50)
for c in clientes: #O C vai rodar as CHAVES da lista composta (CLIENTES)
    print(f'O nome do cliente é {c[0]}, e a sua idade atual é {c[1]} anos.')
    # Aqui o programa lerá os nomes e as idades de acordo com o LOOP do FOR, porém com a formatação do PRINT

print('-='*50)
print('-='*50)
print('----Alimentando uma Lista e Transferindo os dados para outra com o FOR----')

dados = list() #Cria a lista que receberá os dados (será 'limpada' posteriormente, para economizar memória).
alunos = list() #Cria a lista composta que receberá os dados

for c in range(0, 3): #Estabelece a quantidade de LOOPS
    dados.append(str(input('Digite o nome do aluno: '))) #insere o nome na lista temporária DADOS
    dados.append(int(input('Digite a idade do aluno: '))) #insere a idade na lista temporária DADOS
    alunos.append(dados[:]) #faz a cópia da lista temporária DADOS para a lista composta ALUNOS
    dados.clear() #limpa a lista temporária DADOS (para economizar memória

print(f'Os dados dos alunos são: {alunos}')

