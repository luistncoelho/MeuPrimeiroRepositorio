#Exercício 49 - Tabuada com o FOR

import time
n = float(input('Digite o número da sua tabuada: '))
tab = 0
print('Você escolheu o número \033[1m{}\033[m. Esta é a sua tabuada:'.format(n))
for c in range (0, 11):
    tab = (c * n)
    print('{} x {} = '.format(n,c),'\033[1;31m',tab,'\033[m')
    time.sleep(1)
    # os comandos de código \033 iniciam e fecham a formatação de cores. Não esquecer das VÍRGULAS antes e depois da variável (TAB).

