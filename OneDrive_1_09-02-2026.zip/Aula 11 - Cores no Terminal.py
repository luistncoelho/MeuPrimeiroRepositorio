#Aula 11 - Cores no Terminal

#Exemplo com Cores Padrão


print('Olá, Mundo!')

print('-'*100)

#Exemplo com Letra Negrito Vermelha e Fundo Amarelo

print('\033[1;31;43mOlá, Mundo!')

print('-'*100)

#Exemplo com Letra Sublinhada Branca com Fundo Vermelho

print('\033[4;30;41mOlá, Mundo!')

print('-'*100)

#Exemplo com Letra Sublinhada Branca com Fundo Lilás (com finalização do comando)

print('\033[4;30;45mOlá, Mundo!\033[m')

print('-'*100)

#Exemplo com variáveis

n1 = float(input('Digite a primeira nota: '))
n2 = float(input('Digite a segunda nota: '))
media = (n1+n2)/2

print('A primeira nota foi \033[34m{:.2f}\033[m, a segunda nota foi \033[33m{:.2f}\033[m e a sua média foi '
      '\033[1;32m{:.2f}\033[m.'.format(n1,n2,media))

print('-'*100)

#Exmplo Utilizando o FORMAT e uma Formatação Prévia de Cores

nome = input('Digite o seu nome: ')

#A lista de cores será utilizada no .format
cores = {'limpa': '\033[m',
         'azul': '\033[34m',
         'amarelo': '\033[33m',
         'brancopreto': '\033[7;30m'}

print('Prazer em te conhecer, {}{}{}!!!'.format(cores['azul'], nome, cores['limpa']))
#O colchete do meio recebe o nome. O primeiro colchete recebe a cor (através da lista) e o último colchete limpa
#a cor (através da lista também). É importante lembrar de se referir à lista "Cores" no FORMAT.

#nome com outra cor:
print('Prazer em te conhecer, {}{}{}!!!'.format(cores['brancopreto'], nome, cores['limpa']))

print('-'*100)
print('-'*100)
print('-'*100)

#Exercício 34 com cores (Aumento de Salário)

print('Exercício 34 com cores (Aumento de Salário)')

salario = float(input('Digite o seu salário: '))

cores = {'limpa': '\033[m',
        'azul': '\033[34m',
        'verde': '\033[32m',
        'amarelonegrito': '\033[1;33m'}

if salario > 1250:
    print('O aumento do salário será de {}10%{}, sendo {}R${:.2f}{}, e o seu novo salário será {}R${:.2f}{}. Parabéns!'
          .format(cores['azul'],cores['limpa'],cores['verde'],(salario*0.1),cores['limpa'],cores['amarelonegrito'],((salario*0.1)+salario),
                  cores['limpa']))
else:
    print('O aumento do salário será de {}15%,{}, sendo {}R${:.2f}{} e o seu novo salário será {}R${:.2f}{}. Parabéns!'
          .format(cores['azul'],cores['limpa'],cores['verde'],(salario * 0.15),cores['limpa'],cores['amarelonegrito'],((salario * 0.15)+salario),
                  cores['limpa']))

print('FIM')



