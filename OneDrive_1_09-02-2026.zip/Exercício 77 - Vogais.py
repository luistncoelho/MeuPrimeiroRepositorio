#Exercício 77 - Vogais

print('-----VOGAIS-----')

tupla = ('carro', 'Moto', 'Onibus', 'Metro', 'Trem', 'balsa', 'Patins', 'Bicileta', 'skate')

v = 0
p = 0

for c in tupla:
    print('\nNa palavra', f'{c},'.strip().upper(), 'temos', end=' ')
    for v in c:
        if v == 'a':
            print(v, end=' ')
        if v == 'e':
            print(v, end=' ')
        if v == 'i':
            print(v, end=' ')
        if v == 'o':
            print(v, end=' ')
        if v == 'u':
            print(v, end=' ')




    #while v <= (len(c)):
     #   a = c.find('a')
      #  v += 1
       # print(a)

    #e = c.find('e')
    #i = c.find('i')
    #o = c.find('o')
    #u = c.find('u')
    #print(a, e, i, o ,u)
