#Exercício 50 - Soma de 6 Números Pares Inteiros

soma = 0
pares = [] #cria uma lista vazia para os números pares (Aqui definidos na condição IF)
impares = [] #cria uma lista vazia para os números pares (Aqui definidos na condição ELSE)
for c in range (0,6):
    n = int(input('Digite um número inteiro: '))
    if (n % 2) == 0:
        soma += n
        pares.append(n) #o comando .APPEND inclui o valor na última posição da lista (neste caso "N" na lista PAR)
    else:
        impares.append(n) #o comando .APPEND inclui o valor na última posição da lista (neste caso "N" na lista ÍMPAR)

print('Os números pares digitados foram \033[1;32m{}\033[m e o resultado da soma deles é igual\n'
      'a: \033[1;31m{}\033[m'.format(pares, soma))
print('Para efeito de registro, os números ímpares digitados foram {}.'.format(impares))