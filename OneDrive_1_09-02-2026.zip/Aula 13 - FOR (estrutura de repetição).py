#Aula 13 - Estrutura de Repetição/Iteração FOR

print('oi') #Esse comando, como todos os outros, mostrará 1 "oi"

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração')
for c in range(0,10): #Já aqui, o FOR mostrará "oi" 10 vezes. Atenção que aqui, iremos de 0 a 9 porque o último número do FOR(10) nunca é contado.
    print('oi')

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + 2 comandos')
for c in range(0,5): #Já aqui, o FOR mostrará "oi" 5 vezes. Atenção que aqui, iremos de 0 a 9 porque o último número do FOR(10) nunca é contado.
    print('oi')
    print('Luís')

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + Contagem')
for c in range(0,5): #Já aqui, o FOR contará 5 vezes (de 0 a 4), lembrando que ele remove o último número (5).
    print(c) #o C (contador) entrará com os números especificados no RANGE

print('FIM')
print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + Regressivo')
for c in range(5,0, -1): #Já aqui, o FOR contará 5 vezes, porém regressivamente (excluirá o 0).
    print(c) #o C (contador) entrará com os números especificados no RANGE

print('FIM')
print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + Regressivo')
for c in range(0, 6, 2): #Já aqui, o FOR até 6, porém de 2 em 2 (ou seja, mostrará 0 - 2 - 4). Não mostrará o 6 pq é o último.
    print(c) #o C (contador) entrará com os números especificados no RANGE

print('FIM')
print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + uma variável especificada')

n = int(input('Digite um número: '))
for c in range(0, n): #Aqui, o N (especificado pelo usuário) será o limitador do FOR
    print(c)
print('FIM')

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + uma variável especificada')

n = int(input('Digite um número: '))
for c in range(0, n+1): #Aqui, o N (especificado pelo usuário) será o limitador do FOR, e o +1 o levará até o último número
    print(c)
print('FIM')

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + uma variável especificada com incremento automático')

n = int(input('Digite um número: '))
for c in range(0,5):
    print(n+c) #Aqui, o número especificado pelo usuário será incrementado pelo contador (neste caso, de 1 em 1)

print('-'*50)

print('Exemplo com estrutura FOR de Repetição/Iteração + uma variável especificada com incremento/passo especificado')

inicio = int(input('Digite o início da contagem: '))
fim = int(input('Digite o fim da contagem: '))
incremento = int(input('Digite o incremento da contagem: '))

for c in range(inicio,fim, incremento):
    print(c)
    # Aqui, toda a contagem será especificada pelo usuário (incluindo o incremento)

print('-' * 50)

print('Exemplo com estrutura FOR de Repetição/Iteração determinando o número de comandos para o usuário')

for c in range(0,4):
    n = int(input('Digite um número: '))
    # Aqui, o comando FOR pedirá para o usuário indicar 4 número (ou alguma info 4x)

print('-' * 50)

print('Exemplo com estrutura FOR de Repetição/Iteração determinando o número de comandos para o usuário e somando')

s = 0 #o S recebe 0 para iniciar a contagem posterior "zerada" (sem nenhum dado)
for c in range (0, 4):
    n = int(input('Digite um número: '))
    s += n #Aqui, o ' S += N' representa 'S = S + N'
print('O resultado é igual a: {} '.format(s))

print('FIM')

print('-' * 50)