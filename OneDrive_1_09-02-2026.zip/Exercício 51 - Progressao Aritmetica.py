#Exercício 51 - Progressão Aritmética

prog = int(input('Digite o primeiro número da sua progressão: '))
razao = int(input('Digite a razão da sua progressão: '))

print(prog, end=' ')

for c in range (0, 9): #Vai de 0 a 9 porque o primeiro termo já foi mostrado no "print(termo)"
    prog += razao
    print(prog, end=' ')
