#Exercício 93 - Aproveitamento Jogador de Futebol

print('----Exercício 93 - Aproveitamento Jogador de Futebol----')

aprov = dict()
listgols = list()
gols = 0
totalgols = 0
aprov['Nome'] = str(input('Digite o nome do jogador: ')).strip().title()
aprov['Partidas'] = int(input(f'Quantas partidas {aprov["Nome"]} jogou? '))
print('-'*100)
for c in range(0, aprov['Partidas']):
    gols = int(input(f'Quantos gols {aprov["Nome"]} na partida {c+1}? '))
    listgols.append(gols)
    totalgols += gols
aprov['Gols'] = listgols
aprov['Total de Gols'] = totalgols
aprov['Média de Gols'] = totalgols/(aprov['Partidas'])
print('-'*100)
print(aprov)
print('-'*100)
for k, v in aprov.items():
    print(f'{k} é igual a: {v}')
print('-'*100)
print(f'O Jogador {aprov["Nome"]} jogou {aprov["Partidas"]} partidas. Veja o seu aproveitamento abaixo:')
for p, g in enumerate(aprov["Gols"]):
    print(f'{"=>":>5}', f'Na partida {p+1}: {g} gols')
print(f'{"=>":>5}', f'O total de gols é: {totalgols}')
print(f'{"=>":>5}', f'Sua média é de {aprov["Média de Gols"]} gols por jogo.')