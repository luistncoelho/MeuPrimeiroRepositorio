#Exercício 86 - MATRIZ

print('----Exercício 86 - MATRIZ----')

p1 = list()
p2 = list()
p3 = list()
p4 = list()
p5 = list()
p6 = list()
p7 = list()
p8 = list()
p9 = list()

n1 = int(input('Digite a posição [0, 0]: '))
p1.append(n1)

n2 = int(input('Digite a posição [0, 1]: '))
p2.append(n2)

n3 = int(input('Digite a posição [0, 2]: '))
p3.append(n3)

n4 = int(input('Digite a posição [1, 0]: '))
p4.append(n4)

n5 = int(input('Digite a posição [1, 1]: '))
p5.append(n5)

n6 = int(input('Digite a posição [1, 2]: '))
p6.append(n6)

n7 = int(input('Digite a posição [2, 0]: '))
p7.append(n7)

n8 = int(input('Digite a posição [2, 1]: '))
p8.append(n8)

n9 = int(input('Digite a posição [2, 2]: '))
p9.append(n9)

print(p1, p2, p3)
print(p4, p5, p6)
print(p7, p8, p9)