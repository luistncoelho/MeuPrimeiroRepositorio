#Aula 17 - LISTAS

print('----Aula 17 - LISTAS----')

lista = [2, 5, 9, 1]
print(lista)

lista[2] = 3 #Substitui o valor ana posição 2 (aqui é o 9) pelo valor = 3.
print(lista)

lista.append(7) #o '.append' inclui um número ao final da lista
print(lista)

lista.sort() #o '.sort()' vai ordenar a lista
print(lista)

lista.sort(reverse=True) #o 'reverse=True' inverte a ordenação da lista (crescente para decrescente)
print(lista)

n = len(lista) #O 'len()' mostra a quantidade de elementos da lista
print(f'Esta lista tem {n} elementos.')

lista.insert(2, 0) #o '.insert()' adiciona um elemento na posição indicada.
#O primeiro valor (2) indica a posição, e o segundo valor (0), indica o número a ser inserido.
print(lista)

lista.pop() #o '.pop()' remove o último elemento da lista (neste caso, o número 1. Lembre-se que a lista foi invertida)
print(lista)

#Caso desejemos remover algum elemento específico, podemos utilizar o POP, porém temos que dar a referência da
#posição do elemento:
lista.pop(2) #Removerá o elemento da posição 2 da lista (neste caso, o 0).
print(lista)

lista.remove(3) #o '.remove' remove o elemento indicado dentro do parênteses (independentemente da sua posição). Neste caso, o número 3.
print(lista)

#Caso você peça para remover um elemento que não esteja na lista, o Python retornará um ERRO. Para evitar isso,
#é possível utilizar a função IF ou um Laço para verificar se o valor está na lista.
if 4 in lista:
    lista.remove(4)
else:
    print('O valor 4 não está na lista.')

#Para mostrar os elementos sem os sinais de lista (Colchetes), utiliza-se o FOR ou WHILE:
for c in lista:
    print(f'{c}')

for pos, c in enumerate(lista): #O ENUMERATE possibilita a visualização da posição do elemento, juntamente com o elemento.
    print(f'O número {c} está na posição {pos}') #Atenção que temos duas variáveis no FOR, uma para a posição, e outra para o valor

#Adicionando valores automaticamente à uma lista:
print('\n---Adicionando valores automaticamente à uma lista:---')
valores = list() #o comando 'LIST()' cria uma lista vazia.
for c in range(0, 5): #Determinará quantas vezes os valores serão pedidos
    valores.append(int(input('Digite um valor: '))) #Incluirá os valores digitados na lista 'VALORES'
print(f'O valores digitados são: {valores}')

#Copiando Listas
print('\n---Cópia da Lista A para B (COM conexão de alterações)---')
a = [2, 3, 4, 7] #Cria a lista 'a'
b = a #Conecta a lista 'a' com 'b'. ATENÇÃO!!! Tudo que for alterado em 'a', será alterado em 'b' e vice-versa.
print(f'Lista A: {a}')
print(f'Lista B: {b}')
b[2] = 8 #Aqui, a posição 2 da lista 'b' (número 4) será alterada e receberá o valor 8. Porém, como houve a 'conexão'
#da lista 'a' com a lista 'b', a mesma coisa acontecerá com a lista 'a'. Ou seja, quando se utiliza o comando de '='
#para copiar listas, tudo ficará conectado, e todas as alterações em uma lista, serão replicadas para as outras.
print(f'Lista A (alterada): {a}')
print(f'Lista B (alterada): {b}')

#Para fazermos a cópia da lista, porém sem a ligação de replica as alterações, utilizamos o comando '[:]'. Exemplo:
print('\n---Cópia da Lista A para B (SEM conexão de alterações)---')
a = [2, 3, 4, 7]
b = a[:] #Aqui, criamos uma cópia da lista 'a' para a lista 'b', porém sem nenhuma ligação posterior
b[2] = 8
print(f'Lista A (original): {a}')
print(f'Lista B (alterada): {b}')