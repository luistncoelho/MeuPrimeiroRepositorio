#Exercício 87 - MATRIZ (Pares e Ímpares)

print('----Exercício 87 - MATRIZ (Pares e Ímpares)----')

p1 = list()
p2 = list()
p3 = list()
p4 = list()
p5 = list()
p6 = list()
p7 = list()
p8 = list()
p9 = list()
par = 0
maior = 0

n1 = int(input('Digite a posição [0, 0]: '))
p1.append(n1)
if n1 % 2 == 0:
    par += n1

n2 = int(input('Digite a posição [0, 1]: '))
p2.append(n2)
if n2 % 2 == 0:
    par += n2

n3 = int(input('Digite a posição [0, 2]: '))
p3.append(n3)
if n3 % 2 == 0:
    par += n3

n4 = int(input('Digite a posição [1, 0]: '))
p4.append(n4)
maior = n4
if n4 % 2 == 0:
    par += n4

n5 = int(input('Digite a posição [1, 1]: '))
p5.append(n5)
if n5 > maior:
    maior = n5
if n5 % 2 == 0:
    par += n5

n6 = int(input('Digite a posição [1, 2]: '))
p6.append(n6)
if n6 > maior:
    maior = 6
if n6 % 2 == 0:
    par += n6

n7 = int(input('Digite a posição [2, 0]: '))
p7.append(n7)
if n7 % 2 == 0:
    par += n7
n8 = int(input('Digite a posição [2, 1]: '))
p8.append(n8)
if n8 % 2 == 0:
    par += n8

n9 = int(input('Digite a posição [2, 2]: '))
p9.append(n9)
if n9 % 2 == 0:
    par += n9
print('-='*50)
print(p1, p2, p3)
print(p4, p5, p6)
print(p7, p8, p9)
print('-='*50)
print(f'A soma dos números pares é igual a {par}.')
print(f'A soma dos valores da terceira coluna é igual a {n3+n6+n9}.')
print(f'O maior número da segunda linha é igual a {maior}.')