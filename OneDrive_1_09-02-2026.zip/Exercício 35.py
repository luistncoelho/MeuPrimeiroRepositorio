#Exercício 35 - Triângulo

r1 = float(input('Digite o valor da primeira reta: '))
r2 = float(input('Digite o valor da segunda reta: '))
r3 = float(input('Digite o valor da terceira reta: '))

if (r1 + r2 > r3) and (r1 + r3 > r2) and (r2 + r3 > r1):
    print('Essas 3 retas formam um triângulo.', end= ' ')
    # O comando " end= '' " buscará o próximo texto do print. Neste caso, "Equilátero"
    if r1 == r2 == r3: #É possível entrar outro 'IF' para complementar o primeiro (porém somente depois de uma Identação)
        print('Equilátero!!!')
else:
    print('Essas 3 retas não formam um triângulo.')

print('FIM')
