#Exercício 38 - Maior e Menor Valor (2 Valores - COndição Aninhada)

print('#Exercício 38 - Maior e Menor Valor (2 Valores - COndição Aninhada)')

n1 = float(input('Digite o primeiro número: '))
n2 = float(input('Digite o segundo número: '))

if n1 > n2:
    print('{:.2f} é o maior valor.'.format(n1))
elif n2 > n1:
    print('{:.2f} é o maior valor.'.format(n2))
else:
    print('Os dois valores são iguais.')

print('FIM')
