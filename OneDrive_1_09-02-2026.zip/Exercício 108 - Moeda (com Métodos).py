#Exercício 108 - Moeda (com Métodos)

print('----Exercício 108 - Moeda (com Métodos)----')

from metodos_pacotes import moeda

p = float(input('Digite o preço: R$'))
print(f'A metade de {moeda.valor(p)} é igual a {moeda.metade(p)}')
print(f'O dobro de {moeda.valor(p)} é igual a {moeda.dobrar(p)}')
print(f'Aumentando 10% de {moeda.valor(p)}, temos um total de {moeda.aumentar(p, 10)}')
print(f'Diminuindo 10% de {moeda.valor(p)}, temos um total de {moeda.diminuir(p, 10)}')