#Exercício 80 - Lista de Números e Posições (MAIS CURTO)

print('----#Exercício 80 - Lista de Números e Posições (MAIS CURTO)----')

ordinal = ('primeiro', 'segundo', 'terceiro', 'quarto', 'quinto')
lista = []

for ord in ordinal:
    n = int(input(f'Digite o {ord} número: '))
    lista.append(n)
    lista.sort()
    pos = lista.index(n)
    if pos == 0:
        print('Número adicionado na posição inicial. ')
    elif pos == len(lista)-1:
        print('Número adicionado na posição final. ')
    else:
        print(f'Número adicionado na posição {pos}.')

print('-='*50)
print(f'Os números digitados na lista, em ordem crescente de valores, são: {lista}')