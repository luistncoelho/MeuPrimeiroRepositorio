#Exercício 26 - Qtd letras "A"

frase = input('Digite uma frase: ').upper()

print('A letra A aparece {} vezes na frase.'.format (frase.count('A')))
print('A letra A aparece a primeira vez, na posição {} na frase.'.format (frase.find('A')))
print('A letra A aparece pela última vez, na posição {} na frase.'.format (frase.rfind('A')))
#o comando "rfind" busca das posições, porém da direita para a esquerda (a contagem continua da esquerda para a direita).

print('-'*20)

#Exercício 26 - Qtd letras "A" (com +1 para tirar o 0 da contagem de posições)

frase = input('Digite uma frase: ').upper()

print('A letra A aparece {} vezes na frase.'.format (frase.count('A')))
print('A letra A aparece a primeira vez, na posição {} na frase.'.format (frase.find('A')+1))
print('A letra A aparece pela última vez, na posição {} na frase.'.format (frase.rfind('A')+1))
