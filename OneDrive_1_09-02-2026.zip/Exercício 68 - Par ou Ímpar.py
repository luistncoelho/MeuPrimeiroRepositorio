#Exercício 68 - Par ou Ímpar

print('----Exercício 68 - Par ou Ímpar----')

import random

escolha = 0
usua = 0
comp = 0
vitor = 0
soma = 0

while True:
    comp = random.randint(0, 3)
    escolha = str(input('Escolha PAR ou ÍMPAR [P / I]: ')).strip().upper()[0]
    usua = int(input('Qual o seu número? '))
    soma = usua + comp
    if escolha == "P" and soma % 2 == 0:
        vitor += 1
        print(f'Parabéns, você escolheu {usua} e o computador, {comp}. Você venceu!!!')
        print('-'*50)
    elif escolha == "I" and soma % 2 != 0:
        vitor += 1
        print(f'Parabéns, você escolheu {usua} e o computador, {comp}. Você venceu!!!')
        print('-' * 50)
    else:
        break
print(f'Você perdeu. Você escolheu o número {usua} e o computador, {comp}.'
      f'\nA quantidade total de vitórias foi {vitor}. Parabéns!!!')