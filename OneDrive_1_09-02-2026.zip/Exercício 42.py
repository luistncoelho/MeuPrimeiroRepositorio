#Exercício 42 - Triângulo (saber se é Equilátero / Isóceles / Escaleno)

print('#Exercício 42 - Triângulo (saber se é Equilátero / Isóceles / Escaleno)')

seg1 = float(input('Digite o primeiro segmento: '))
seg2 = float(input('Digite o segundo segmento: '))
seg3 = float(input('Digite o terceiro segmento: '))

if seg1 == seg2 and seg2 == seg3: #ou: seg1 == seg2 == seg3 (isso deixa o código mais limpo.
    print('Os 3 segmentos podem formar um triângulo EQUIlÁTERO.')
elif seg1 + seg2 > seg3 and seg1 + seg3 > seg2 and seg2 + seg3 > seg1 and (seg1 == seg2 or seg1 == seg3 or seg2 == seg3):
    print('Os 3 segmentos podem formar um triângulo ISÓCELES.')
elif seg1 + seg2 > seg3 and seg1 + seg3 > seg2 and seg2 + seg3 > seg1:
    print('Os 3 segmentos podem formar um triângulo ESCALENO.')
else:
    print('Os 3 segmentos não podem formar um triângulo.')

print('FIM')

#EXEMPLO DE CÓDIGO MAIS LIMPO

print('#Exercício 42 - Triângulo (saber se é Equilátero / Isóceles / Escaleno) - Mais "Clean"')

seg1 = float(input('Digite o primeiro segmento: '))
seg2 = float(input('Digite o segundo segmento: '))
seg3 = float(input('Digite o terceiro segmento: '))

if seg1 + seg2 > seg3 and seg1 + seg3 > seg2 and seg2 + seg3 > seg1:
    print('Os 3 segmentos podem formar um triângulo.', end= ' ') # " , end= '' " puxa o próximo PRINT ('Equilátero')
    if seg1 == seg2 == seg3:
        print('EQUIlÁTERO.')
    elif seg1 != seg2 != seg3 != seg1: #Lê-se " != DIFERENTE "
        print('ESCALENO.')
    else:
        print('ISÓCELES.')
else:
    print('Os 3 segmentos não podem formar um triângulo.')
