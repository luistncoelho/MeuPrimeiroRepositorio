#Exercício 64 - Quantidade e Soma de Números Inteiros

print('----Quantidade e Soma de Números Interiros----')

c = 0
soma = 0
qtd = 0

while c == 0:
    n = int(input('Digite o número desejado. Caso deseje sair, digite "999": '))
    if n != 999: #O número '999' é chamado de FLAG na programação, pois indica a interrupção de um laço. Ele não pode estar na contagem final.
        soma += n
        qtd += 1
    else:
        c += 1
print(f'A quantidade de números digitados foi {qtd} e a soma deles é igual a {soma}.') #Exemplo de "F-string" (substitui o ".format()").

