# Exercício 85 - Lista 7 números (Par e Ímpar)

print('----Exercício 85 - Lista 7 números (Par e Ímpar)-----')

lista = [[], []]
n = 0

for c in range(0, 7):
    n = int(input(f'Digite o {c + 1}° número: '))
    if n % 2 == 0:
        lista[0].insert(0, n)
    else:
        lista[1].insert(1, n)

lista[0].sort()
list


print(lista)
print(f'Os números pares digitados são: {lista[0]}')
print(f'Os números ímpares digitados são: {lista[1]}')