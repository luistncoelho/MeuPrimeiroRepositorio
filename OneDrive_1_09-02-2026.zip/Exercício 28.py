#Exercício 28 - Escolhendo um número aleatório entre 0 e 5

import random
n0 = int(0)
n1 = int(1)
n2 = int(2)
n3 = int(3)
n4 = int(4)
n5 = int(5)
numeros = n0, n1, n2, n3, n4, n5
escolhacomp = random.choice(numeros)

escolhausuario = int(input('Escolha um número entre 0 e 5: '))
#Lembre-se sempre de declarar se a variável é INT ou FLOAT em caso de números


if escolhacomp == escolhausuario:
    print('Parabéns, você venceu! O número escolhido pelo computador foi {}, e o número escolhido por você \n'
          'foi {}.'.format(escolhacomp, escolhausuario))
else:
    print('Tente outra vez. O número escolhido pelo computador foi {}, e o número escolhido por você \n'
          'foi {}.'.format(escolhacomp, escolhausuario))

print('FIM')

print('-'*50)
