#Aula 09 - Manipulação de Texto

frase = 'Curso em Vídeo Python'
print(frase)

print(frase[9])

print(frase[9:13])

print(frase[9:])

print(frase[9:21])

print(frase[9:21:2])

print(frase[:5])

print(frase[9::3])

print(len(frase))

print(frase.count('o'))

print(frase.count('o', 0, 13))

print('Curso' in frase)

print(frase.find('Vídeo'))

print(frase.replace('Python','Android'))

print(frase.upper())

print(frase.upper().count('O'))

print(frase.lower())

print(frase.lower().count('o'))

print(frase.capitalize())

print(frase.title())

#Nova Frase - 'Aprenda Python' (Com espaços) - Utilização do STRIP

frase = '   Aprenda Python   '
print(frase)

print(frase.strip())

print(len(frase.strip()))

print(frase.rstrip())

print(frase.lstrip())

print('-'.join(frase.strip()))

#Utilização do SPLIT

frase = frase.replace('   Aprenda Python   ', 'Curso em Vídeo Python')
print(frase)

print(frase.split())

dividido = frase.split()
print(dividido[2])

print(dividido[2] [3])