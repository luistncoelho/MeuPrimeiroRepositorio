#Exercício 92 - Formulário Carteira de Trabalho

print('----Exercício 92 - Formulário Carteira de Trabalho----')

from datetime import date

form = dict()
dados = list()
anoatual = date.today().year
iniciar = ' '
tabela = ' '
while iniciar not in 'S/N':
    iniciar = str(input('Deseja inserir dados [S/N]? ')).strip().upper()
    if iniciar == 'S':
        while True:
            continuar = ' '
            form['Nome'] = str(input('Nome: ')).strip().title()
            form['Idade'] = anoatual - (int(input('Ano de Nascimento: ')))
            form['CTPS'] = int(input('Nº CTPS (Caso não tenha, digite 0): '))
            if form['CTPS'] > 0:
                form['AnoContrato'] = int(input('Ano de Contratação: '))
                form['Salario'] = float(input('Salário: '))
                form['Aposentar'] = (form['AnoContrato']+35)-(anoatual-form['Idade'])
            else:
                form['AnoContrato'] = 0
                form['Salario'] = 0
                form['Aposentar'] = 0
            dados.append(form.copy())
            form.clear()
            print('-='*50)
            while continuar not in 'S/N':
                continuar = str(input('Deseja inserir mais dados [S/N]: ')).strip().upper()
                print('-='*50)
            if continuar == 'N':
                break
        while tabela not in 'S/N':
            tabela = str(input('Deseja visualizar a tabela de funcionários [S/N]? ')).upper()
            if tabela == 'S':
                for c in dados: #O 'C' vai percorrer as posições da lista
                    name, age, workdoc, contract, salary, retirement = c.values() #Criamos variáreis (neste caso 6) para receberem os valores das chaves dos dicionários
                    print(f'Nome: {name}\nIdade: {age}\nCTPS: {workdoc}\nAno de Contrato: {contract}\nSalário: {salary}\n'
                        f'Aposentadoria: {retirement}') #através do 'FOR' e das variáveis criadas nele, imprimirá os valores de cada dicionário contido na lista
                    print('-='*50)
    print('Programa finalizado.')
