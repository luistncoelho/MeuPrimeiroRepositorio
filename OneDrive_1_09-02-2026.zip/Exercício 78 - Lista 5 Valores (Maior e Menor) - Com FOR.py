#EXERCÍCIO 78 - Lista 5 Valores (Maior e Menor) - Com FOR

print('EXERCÍCIO 78 - Lista 5 Valores (Maior e Menor) - com FOR')

maior = 0
menor = 0
lista = []

for c in range(0, 5):
    n = int(input(f'Digite o {c + 1}° número: '))
    lista.append(n)
    if c == 0:
        maior = n
        menor = n
    if n > maior:
        maior = n
    if n < menor:
        menor = n

print(f'A lista digitada foi: {lista}')
print(f'O maior número digitado foi {maior} e suas posições são', end=' ')

for pos, c in enumerate(lista):
    if c == maior:
        print(pos, end=' ')

print(f'\nO menor número digitado foi {menor} e suas posições são', end=' ')

for pos, c in enumerate(lista):
    if c == menor:
        print(pos, end=' ')