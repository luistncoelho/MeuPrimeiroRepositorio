#Exercício 74 - Tupla com Números Aleatórios

print('---Tuplas com Números Aleatórios / Maior / Menor---')

from random import randint

tupla = randint(0, 9), randint(0, 9), randint(0, 9), randint(0, 9), randint(0, 9) # Atribui 5 números aleatórios entre 0 e 9 para a TUPLA.
maior = max(tupla)
menor = min(tupla)


print(f'Os números sorteados são: ', end=' ')

for c in tupla: # Faz o contador (c) buscar os elementos dentro da TUPLA. O Laço ocorrerá cinco vezes, pois há 5 números na TUPLA
    print(c, end=' ') # Printa o C com os elementos da TUPLA. O comando 'end= ' coloca o LAÇO em linha horizontal.
print(f'\nO maior número sorteado é: {maior}') # O '\n' encerra o comando 'end= '.
print(f'O menor número sorteado é: {menor}')
