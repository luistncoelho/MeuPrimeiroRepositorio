#Exercício Aula 6 - Soma entre 2 números reais
n1 = float(input('Digite o primeiro número: '))
n2 = float(input('Digite o segundo número: '))
soma = n1 + n2

print('A soma entre {} e {} vale {}'.format(n1,n2,soma))



#Exercício comando 'IS' - Número (numeric)
n = input('Digite um número: ')
print(n.isnumeric())


#Exercício comando 'IS' - Letra (aplha)
n = input('Digite uma letra:')
print(n.isalpha())


#Exerício comando 'IS' - Letras e Números (Alpha numérico - alphanum)
n = input('Digite uma letra ou um número:')
print(n.isalnum())