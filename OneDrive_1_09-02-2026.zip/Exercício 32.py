#Exercício 32 - Ano Bissexto

ano = int(input('Digite o ano: '))
ano4 = float(ano % 4)
ano100 = float(ano % 100)
ano400 = float(ano % 400)

if (ano4 == 0) and ((ano4 + ano100 > 0) or (ano4 + ano100 + ano400 == 0)):
    print('Este ano é bissexto')
else:
    print('Este ano não é bissexto')

print('FIM')