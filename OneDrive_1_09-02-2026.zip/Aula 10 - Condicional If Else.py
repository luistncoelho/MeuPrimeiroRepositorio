#Aula 10 - Condições (If / Else)

#Exemplo Carro Novo/Velho
tempo = int(input('Quantos anos tem o seu carro? '))

if tempo <= 3:
    print('Seu carro é novo.')
else:
    print('Seu carro é velho.')

print('--FIM--')

print('-'*50)
#----------------------------
#Condição Simplificada

tempo = int(input('Quantos anos tem o seu carro? '))

print('O seu carro é novo.'if tempo <=3 else('O seu carro é velho.'))
print('--FIM--')

print('-'*50)
#----------------------------
#Exemplo 2 - Estrutura Simples - Nome específico

nome = str(input('Qual é o seu nome? '))

if nome == 'Luís Thiago' : #o nome deve estar entre aspas porque é uma STRING.
    print("Welcome to Servenaya, comrade!") #esta frase só aparecerá quando o nome for "Luís Thiago"
print('Have a nice day, {}!'.format(nome))

print('-'*50)
#----------------------------
#Exemplo 2 - Estrutura Composta - Nome específico

nome = str(input('Qual é o seu nome? '))

if nome == 'Luís Thiago': #nunca esquecer dos dois pontos " : "
    print('Welcome to Severnaya, comrade!')

else:
    print('I am sorry, you are not allowed in this area.')

print('FIM')

print('-'*50)
#----------------------------
#Exemplo 3 - Média de Notas

n1 = float(input('Digite a nota 1: '))
n2 = float(input('Digite a nota 2: '))
m = (n1+n2)/2

if m <6 :
    print('Sua média é {}. Você está reprovado.'.format(m))
else:
    print('Sua média é {}. Você está aprovado. Parabéns!'.format(m))

print('-'*50)
#----------------------------
