#Exercício 22 - Manipulação de Texto - Nome

nome = input('Digite o seu nome: ')

print(nome.upper())

print(nome.lower())

nome = nome.strip()
letras = len(nome) - nome.count(" ") #Este comando subtrai os espaços (em nome.count) do total de caracteres

print('Este nome contém {} letras'.format(letras))

nomeseparado = nome.split()
qtdprimeironome = len(nomeseparado[0])

print('O primeiro nome contém {} letras.'.format(qtdprimeironome))