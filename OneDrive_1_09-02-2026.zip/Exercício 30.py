#Exercício 30 - PAR ou ÍMPAR

numero = float(input('Digite um número: '))

resto = float(numero % 2) #NUNCA esquecer de declarar se o número é INT ou FLOAT!!!!!

if resto == 0:
    print('Este número é par.')
else:
    print('Este número é ímpar.')

print('FIM')