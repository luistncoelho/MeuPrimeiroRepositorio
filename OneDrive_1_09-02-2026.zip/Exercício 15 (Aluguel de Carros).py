print('#Exercício 15 - Aluguel de Carros')
print('Carros disponíveis e respectivas diárias: \nMobi - R$70,00 \nUno - R$80,00 \nArgo - R$90,00 \nRenegade - R$105,00')
print()

mobi = int(70)
uno = int(80)
argo = int(90)
renegade = int(105)
seguro = int(20)
terceiros = int(10)

carroEscolhido = input('Digite o carro escolhido: ')
dias = int(input('Digite a quantidade de dias de locação: '))

if carroEscolhido == 'Mobi':
    print('Valor da diária do carro: R${:.2f}'.format(mobi))
    print('valor do seguro (diária): R$20,00')
    print('Valor do seguro terceiros (diária): R$10,00')
    taxaLocação = float((mobi+seguro+terceiros)*0.12)
    print('Valor da taxa de locação (diária): R${:.2f}'.format(taxaLocação))
    print('Para {} dias, o Valor Total da locação é de: R${:.2f}'.format(dias, dias*(mobi+seguro+terceiros+taxaLocação)))

elif carroEscolhido == 'Uno':
    print('Valor da diária do carro: R${:.2f}'.format(uno))
    print('valor do seguro (diária): R$20,00')
    print('Valor do seguro terceiros (diária): R$10,00')
    taxaLocação = float((uno+seguro+terceiros)*0.12)
    print('Valor da taxa de locação (diária): R${:.2f}'.format(taxaLocação))
    print('Para {} dias, o Valor Total da locação é de: R${:.2f}'.format(dias, dias * (uno+seguro+terceiros+taxaLocação)))

elif carroEscolhido == 'Argo':
    print('Valor da diária do carro: R${:.2f}'.format(argo))
    print('valor do seguro (diária): R$20,00')
    print('Valor do seguro terceiros (diária): R$10,00')
    taxaLocação = float((argo + seguro + terceiros) * 0.12)
    print('Valor da taxa de locação (diária): R${:.2f}'.format(taxaLocação))
    print('Para {} dias, o Valor Total da locação é de: R${:.2f}'.format(dias, dias * (argo + seguro + terceiros + taxaLocação)))

elif carroEscolhido == 'Renegade':
    print('Valor da diária do carro: R${:.2f}'.format(renegade))
    print('valor do seguro (diária): R$20,00')
    print('Valor do seguro terceiros (diária): R$10,00')
    taxaLocação = float((renegade+seguro+terceiros)*0.12)
    print('Valor da taxa de locação (diária): R${:.2f}'.format(taxaLocação))
    print('Para {} dias, o Valor Total da locação é de: R${:.2f}'.format(dias, dias*(renegade+seguro+terceiros+taxaLocação)))

else: print('Carro não existente. Escolha um carro da lista apresentada. Muito Obrigado!')

print()