#Exercício 21 - Tocar MP3

print('#Exercício 21 - Tocar MP3')
import playsound
from playsound import playsound
playsound('C:\\Users\\Luis\Music\\Judgment Night\\01 Just Another Victim.mp3')
