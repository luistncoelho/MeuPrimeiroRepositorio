#Aula 14 - Estrutura de Repetição WHILE

#EXEMPLO 1
import time

c = 1 #Declaramos a variável para que ela já tenha um valor
while c < 10: #Estrutura lógica (funcionará até que C atinga o valor 10)
    print(c) #Imprimirá a variável
    c += 1 #Sempre adicionará um valor ao C (neste caso +1). Incremento necessário para que a contagem chegue ao limite (aqui = 10)
    time.sleep(0.5) #Frescura minha (para praticar o tempo que o Python demora para mostrar os valores)
print('FIM')
print('-'*50)

#EXEMPLO 2
n = 1
while n != 0: #Lembrar que o " != " significa DIFERENTE
    n = int(input('Digite um valor. Para sair, digite 0: '))
print('FIM')
print('-'*50)

#Exemplo 3

listanomes = []
c = 'S' #Inicia a variável com o valor padrão
while c == 'S': #Lógica do WHILE (neste caso = "S" de sim)
    nome = input('Digite o seu primeito nome: ').upper() #O UPPER padronizará todas as letras)
    listanomes.append(nome) #Insere o NOME no final da lista de nomes (variável LISTANOMES)
    c = input('Quer continuar [S / N]? ').upper() #Novamente, o UPPER fará com que as letras sejam padronizadas)
print(listanomes) #Imprime a lista com os nomes
print('-' * 50)

#Exemplo 4 (Quantidade de números PARES E ÍMPARES)

par = 0
impar = 0
c = 'S'

while c == 'S':
    n = int(input('Digite um número: '))
    if n % 2 == 0:
        par += 1
    else:
        impar += 1
    c = input('Deseja continuar [S / N}: ').upper()
print('Você digitou {} números pares e {} números ímpares.'.format(par, impar))

