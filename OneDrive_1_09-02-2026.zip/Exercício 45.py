#Exercício 45 - Jokenpô (Pedra, Papel e Tesoura)

print('#Exercício 45 - Jokenpô (Pedra, Papel e Tesoura)')

import random

participante = input('Escolha a opção:\n'
                '1) Pedra\n'
                '2) Papel\n'
                '3) Tesoura\n'
                '\n'
                'Digite a opção escolhida: ').capitalize()

opcoescomputador = 'Pedra', 'Papel', 'Tesoura'
computador = random.choice(opcoescomputador)

if participante == computador:
    print('Você escolheu {} e o computador escolheu {}. Empate!'.format(participante, computador))
elif (participante == 'Pedra' and computador == 'Tesoura') or (participante == 'Papel' and computador == 'Pedra')\
        or (participante == 'Tesoura' and computador == 'Papel'):
    print('Você escolheu {} e o computador escolheu {}. Você venceu!'.format(participante, computador))
else:
    print('Você escolheu {} e o computador escolheu {}. Você perdeu. Tente outra vez.'.format(participante, computador))

print('FIM')