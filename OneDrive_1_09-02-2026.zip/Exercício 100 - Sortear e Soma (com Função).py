# Exercício 100 - Sortear e Soma (com Função)

print('----Exercício 100 - Sortear e Soma (com Função)----')
import random


def sortear():
    valores = random.sample(range(1, 10), 5)
    print(f'Os 5 valores sorteados foram:', end=' ')
    for c in valores:
        print(f'{c}', end=' ')
        lista.append(c)


def somapar():
    soma = 0
    for c in lista:
        if c % 2 == 0:
            soma += c
    print(f'\nA soma dos valores pares da lista sorteada é igual a: {soma}')

lista = []
sortear()
somapar()

