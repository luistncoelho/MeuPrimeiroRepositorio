#Exercício 107 - Moeda (com Métodos)

print('----Exercício 107 - Moeda (com Métodos)----')

from metodos_pacotes import variacao

p = float(input('Digite o preço: R$'))
print(f'A metade de {p} é igual a {variacao.metade(p)}')
print(f'O dobro de {p} é igual a {variacao.dobrar(p)}')
print(f'Aumentando 10% de {p}, temos um total de {variacao.aumentar(p, 10)}')
print(f'Diminuindo 10% de {p}, temos um total de {variacao.diminuir(p, 10)}')