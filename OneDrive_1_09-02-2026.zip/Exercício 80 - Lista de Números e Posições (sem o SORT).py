#Exercício 80 - Lista de Números e Posições (sem o SORT)

print('----Exercício 80 - Lista de Números e Posições (sem o SORT)----')
lista = []
qtd = int(input('Digite a quantidade de números da sua lista: '))
primnu = int(input('Digite o 1º número: '))
lista.append(primnu)
print('1º número adicionado com sucesso!')
menornu = primnu
maiornu = primnu

for c in range(1, qtd):
    n = int(input(f'Digite o {c+1}º número: '))
    if n <= menornu:
        print('Número adicionado na posição inicial. ')
        lista.insert(0, n)
        menornu = n
    elif n >= maiornu:
        print('Número adicionado na posição final. ')
        lista.insert(c, n)
        maiornu = n
    else:
        pos = 0
        while True:
            if n <= lista[1+pos]:
                lista.insert(1+pos, n)
                print(f'Número adicionado na posição {1+pos}.')
                break
            pos += 1

print('-='*50)
print(f'Os números digitados na lista, em ordem crescente de valores, são: {lista}')