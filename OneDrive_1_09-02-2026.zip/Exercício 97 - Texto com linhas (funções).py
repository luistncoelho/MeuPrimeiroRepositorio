#Exercício 97 - Texto com linhas (funções)

print('----Exercício 97 - Texto com linhas (funções)----')

def escreva(msg):
    tam = len(msg)
    for c in range(0, tam):
        print('-', end='')
        c += 1
    print(f'\n{msg}')
    for c in range(0, tam):
        print('-', end='')
        c += 1

mensagem = str(input('Digite a sua mensagem: ')).title()

escreva(mensagem)