#Exercício 76 - LIsta de Compras com 1 Tupla

print('------Lista de Produtos e Preços------')

listapreços = ('Lápis', '1.75', 'Borracha', '2.00', 'Caderno', '15.90', 'Estojo', '25.00', 'Transferidor', '4.20',
               'Compasso', '9.99', 'Mochila', '120.32', 'Canetas', '22.30', 'Livro', '34.90')

c = 0

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('........................ R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('..................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('...................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('....................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('................. R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('..................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('...................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('...................... R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1

for c in range(c, c+1):
    print(listapreços[c], end=' ')
    c += 1
print('........................ R$', end=' ')
for c in range(c, c+1):
    print(f'{listapreços[c]:>6}')
    c += 1