#Exercício 27 - Primeiro e Último nomes

nomecompleto = input('Digite o seu nome completo: ').strip()

nomepartes = nomecompleto.split()

primeironome = nomepartes[0]

ultimonome = nomepartes[-1]


print('Primeiro nome: {}'.format(primeironome))
print('Último nome: {}'.format(ultimonome))