#Exercício 59 - Menu Matemática

print('----MENU MATEMÁTICA----')

c = 'S'
resultado = 0

while c == 'S':
    n1 = float(input('Digite o primeiro número: '))
    n2 = float(input('Digite o segundo número: '))
    operacao = int(input('O que deseja realizar?\n' #O INT joga a opção desejada para número inteiro (para os IF embaixo)
                 '[1] Somar\n'
                 '[2] Multiplicar\n'
                 '[3] Maior número\n'
                 '[4] Digitar novos números\n'
                 '[5] Sair do programa\n'
                 '\n'
                 ''
                 'Digite a opção desejada: '))
    if operacao != 4:
        if operacao < 5:
            if operacao == 1:
                resultado = n1 + n2
            elif operacao == 2:
                resultado = n1 * n2
            elif operacao == 3:
                resultado = max(n1, n2) #A função MAX retorna o MAIOR valor entre os argumentos (neste caso, N1 e N2)
            print('O resultado da sua operação é {:.2f}.'.format(resultado))
            c = input('Deseja realizar outra operação [S / N]? ').upper()
        else:
            c = 'N'

print('Você saiu do programa.'. format(resultado))
