#Exercício 45 - Valor do Produto com Juros no Cartão

print('#Exercício 45 - Valor do Produto com Juros no Cartão')

preco = float(input('Qual o preço do produto? '))
condpag = int(input('Selecione a CONDIÇÃO DE PAGAMENTO. Veja as opções abaixo\n'
                    '1) à vista (dinheiro ou cheque). 10% de desconto\n'
                    '2) à vista (cartão). 5% de desconto\n'
                    '3) crédito (em até 2x sem juros)\n'
                    '4) crédito (de 3x à 12x). 20% de juros no valor total\n'
                    '\n'
                    'Digite a opção selecionada: '))

if condpag == 1:
    print('O valor final da sua compra será R${:.2f}.'.format((preco*90)/100))
elif condpag == 2:
    print('O valor final da sua compra será R${:.2f}.'.format((preco*95)/100))
elif condpag == 3:
    print('O valor final da sua compra será R${:.2f}.'.format(preco))
elif condpag == 4:
    parcelas = int(input('Em quantas parcelas (até 12x)? ')) #É possível criar variável dentro do IF / ELIF.
    valorparc = ((preco*120)/100) / parcelas
    print('O valor final da sua compra será R${:.2f}, e cada parcela custará R${:.2f}.'.format((preco*120)/100, valorparc))


print('FIM')
