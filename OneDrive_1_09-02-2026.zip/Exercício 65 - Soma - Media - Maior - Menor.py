#Exercício 65 - Soma, Média, Maior e Menor

print('----Soma, Média, Maior e Menor----')

n = float(input('Digite o número desejado: '))
qtd = 1
soma = n
media = n / 1
maior = n
menor = n
continuar = input('Deseja continuar [S / N]? ').upper()
if continuar == 'S':
    while continuar == 'S':
        n = float(input('Digite o número desejado: '))
        qtd += 1
        soma += n
        media = float(soma / qtd)
        if n > maior:
            maior = n
        elif n < menor:
            menor = n
        continuar = input('Deseja continuar [S / N]? ').upper()
print(f'A quantidade de números digitados foi {qtd}\n'
      f'A soma dos números digitados é igual a: {soma:.2f}\n'
      f'A média dos números digitados é igual a: {media:.2f}\n'
      f'O maior número digitado foi {maior}\n'
      f'O menor número digitado foi {menor}') #Todos os "PRINT" estão com a função "F-string" que substitui o ".format()".