#Exercício 76 - LIsta de Compras com 1 Tupla (Alternativo - Mais Curto)

print('------------LISTA DE COMPRAS----------s--')

listapreços = ('Lápis', 1.75, 'Borracha', 2.00, 'Caderno', 15.90, 'Estojo', 25.00, 'Transferidor', 4.20,
               'Compasso', 9.99, 'Mochila', 120.32, 'Canetas', 22.30, 'Livro', 34.90)

elemento = 0
c = 0

while c <= len(listapreços)-1:
    print(f'{(listapreços[elemento]):<30}'.replace(' ','.'),'R$',f'{listapreços[elemento+1]:6.2f}')
    elemento += 2
    c += 2



