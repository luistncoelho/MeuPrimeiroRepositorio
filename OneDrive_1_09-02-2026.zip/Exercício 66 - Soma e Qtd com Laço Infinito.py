#Exercício 66 - Soma e Qtd com Laço Infinito

print('----Exercício 66 - Soma e Qtd com Laço Infinito----')

qtd = 0
soma = 0
n = 0

while True:
    n = float(input('Digite um número. Caso queira sair, digite "999": '))
    if n == 999:
        break

    else:
        qtd += 1
        soma += n


print(f'A quantidade de números digitados foi {qtd} e a sua soma é igual a {soma:.2f}')

print('FIM')